# =============================================================================
# make_synthetic_data.R — build the synthetic example dataset.
#
# Writes data/iv_match_synthetic.dta, the file every script in this archive
# reads by default.  The real analysis file is restricted (see README.md in
# this folder); this stand-in has the same 50 columns, the same types, and
# roughly the same marginal distributions, so the pipeline runs end to end and
# produces output of the right shape.  The estimates it produces are NOT the
# paper's estimates.
#
# Two modes:
#   * If LIV_DATA_FILE points at the real file and it can be read, each
#     column's type and marginal distribution are learned from it.  Columns
#     are then drawn INDEPENDENTLY of one another, so no real record survives
#     into the output: a synthetic row is a mix of values from many different
#     real patients.  Hospital identifiers are replaced with synthetic ones.
#   * Otherwise it falls back to the schema documented in README.md, with
#     plausible marginals hard-coded below.  No real data is needed.
#
# In both modes the dependence structure is imposed afterwards and is entirely
# synthetic: hospital -> surgeon tendency to operate (pref) -> surgery (surg)
# -> outcomes (died, prolonged).
#
# Base R plus `foreign` only, so it runs unattended on a machine with no
# package installation and no network.
#
# Environment variables (all optional):
#   LIV_DATA_FILE       real .dta to learn marginals from
#   LIV_SYNTH_OUT       output path (default: beside this script)
#   LIV_SYNTH_N         rows to generate (default 5000)
#   LIV_SYNTH_SEED      random seed (default 20260602)
#   LIV_SYNTH_KEEP_ALL  1 to mirror every column of the real file, not just
#                       the 50 documented ones.  Off by default: extra columns
#                       may carry identifiers.
#
# Run it as:  Rscript data/make_synthetic_data.R
# (Sourcing it interactively writes to getwd() unless LIV_SYNTH_OUT is set.)
# =============================================================================

library(foreign)

getenv <- function(nm, default) {
  v <- Sys.getenv(nm, unset = NA_character_)
  if (is.na(v) || !nzchar(v)) default else v
}

n_out    <- as.integer(getenv("LIV_SYNTH_N", "5000"))
seed     <- as.integer(getenv("LIV_SYNTH_SEED", "20260602"))
keep_all <- identical(getenv("LIV_SYNTH_KEEP_ALL", "0"), "1")
real_in  <- getenv("LIV_DATA_FILE", "")

# Default output: next to this script when run with Rscript, else getwd().
this_file <- sub("^--file=", "",
                 grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE))
here_dir  <- if (length(this_file) == 1L) dirname(normalizePath(this_file)) else getwd()
out_file  <- getenv("LIV_SYNTH_OUT", file.path(here_dir, "iv_match_synthetic.dta"))

set.seed(seed)

# The 50 columns documented in README.md, in the order the pipeline expects.
doc_cols <- c("shafi17", "died", "prolonged", "hospid", "surg", "pref",
              "comorb", "angus", "age", paste0("ynel", 1:31),
              paste0("p_cat", 1:5), "female", "hisp", "afam", "other",
              "disability_bin")


# =============================================================================
# 1. Learn marginals from the real file, or fall back to the documented schema
# =============================================================================

real <- NULL
if (nzchar(real_in)) {
  real <- tryCatch(suppressWarnings(read.dta(real_in)),
                   error = function(e) {
                     message("Could not read ", real_in, ": ", conditionMessage(e))
                     NULL
                   })
}
learned <- !is.null(real)

if (learned) {
  message("Learning marginals from ", real_in, " (", nrow(real), " rows)")
  cols <- if (keep_all) union(doc_cols, names(real)) else doc_cols
  missing_cols <- setdiff(cols, names(real))
  if (length(missing_cols)) {
    message("Not in the real file, falling back for: ",
            paste(missing_cols, collapse = ", "))
  }
  if (keep_all) {
    warning("LIV_SYNTH_KEEP_ALL is set: columns beyond the documented 50 may ",
            "carry identifiers. Check the output before sharing it.",
            call. = FALSE)
  }
  # Each column is resampled on its own, so rows are recombinations, not records.
  draw_col <- function(nm) {
    if (!nm %in% names(real)) return(NULL)
    v <- real[[nm]]
    v <- v[!is.na(v)]
    if (!length(v)) return(NULL)
    sample(v, n_out, replace = TRUE)
  }
} else {
  message("No real file read; using the documented schema and hard-coded marginals")
  cols <- doc_cols
  draw_col <- function(nm) NULL
}

# Fallback marginals, used when a column was not learned.
fallback_col <- function(nm, n) {
  if (nm == "age")     return(round(pmin(pmax(rnorm(n, 60, 18), 18), 105)))
  if (nm == "comorb")  return(rpois(n, 1.8))
  if (nm == "angus")   return(rbinom(n, 1, 0.20))
  if (nm == "female")  return(rbinom(n, 1, 0.55))
  if (nm == "hisp")    return(rbinom(n, 1, 0.12))
  if (nm == "afam")    return(rbinom(n, 1, 0.13))
  if (nm == "other")   return(rbinom(n, 1, 0.08))
  if (nm == "disability_bin") return(rbinom(n, 1, 0.10))
  if (grepl("^ynel", nm))  return(rbinom(n, 1, 0.08))
  if (grepl("^p_cat", nm)) return(rbinom(n, 1, 0.20))
  rbinom(n, 1, 0.5)
}

dat <- list()
for (nm in setdiff(cols, c("shafi17", "died", "prolonged", "hospid",
                           "surg", "pref"))) {
  v <- draw_col(nm)
  if (is.null(v)) v <- fallback_col(nm, n_out)
  dat[[nm]] <- v
}


# =============================================================================
# 2. Hospitals and surgeon tendency to operate (the instrument)
# =============================================================================
# Each synthetic hospital gets its own small pool of surgeons, and a patient's
# TTO is that of one surgeon at their hospital.  This reproduces the feature
# the positivity diagnostic is about: a hospital covers only part of the TTO
# range, and has few distinct values.

hosp_sizes <- function(n) {
  sizes <- integer(0)
  while (sum(sizes) < n) sizes <- c(sizes, max(5L, round(rlnorm(1, log(60), 0.9))))
  sizes[length(sizes)] <- sizes[length(sizes)] - (sum(sizes) - n)
  sizes[sizes > 0]
}
sizes  <- hosp_sizes(n_out)
hospid <- rep(seq_along(sizes), times = sizes)   # synthetic ids, 1..H

# TTO marginal: learned from the real file if available, else a Beta.
pref_pool <- if (learned && "pref" %in% names(real)) {
  p <- real$pref[!is.na(real$pref)]
  if (length(p)) p else NULL
} else NULL
draw_pref <- function(k) {
  if (!is.null(pref_pool)) sample(pref_pool, k, replace = TRUE)
  else round(pmin(pmax(rbeta(k, 5, 2.5), 0.01), 1), 3)
}

pref <- numeric(n_out)
for (h in seq_along(sizes)) {
  idx   <- which(hospid == h)
  n_sur <- max(1L, rpois(1, 5))             # surgeons at this hospital
  pool  <- draw_pref(n_sur)                 # their tendencies to operate
  pref[idx] <- sample(pool, length(idx), replace = TRUE)
}

dat$hospid <- as.integer(hospid)
dat$pref   <- pref


# =============================================================================
# 3. Synthetic treatment and outcomes
# =============================================================================
# Every dependence below is invented here: pref shifts surgery, and surgery and
# case mix shift the outcomes.  Nothing is estimated from the real data.

age_z  <- as.numeric(scale(dat$age))
sick   <- 0.5 * age_z + 0.8 * dat$angus + 0.15 * dat$comorb
p_surg <- plogis(-0.4 + 2.2 * (dat$pref - mean(dat$pref)) - 0.25 * sick)
dat$surg <- rbinom(n_out, 1, p_surg)

dat$died      <- rbinom(n_out, 1, plogis(-3.6 + 0.9 * sick - 0.25 * dat$surg))
dat$prolonged <- rbinom(n_out, 1, plogis(-2.4 + 0.8 * sick - 0.30 * dat$surg))

# Cholecystitis sub-population flag: the pipeline filters on shafi17 == 1.
dat$shafi17 <- rbinom(n_out, 1, 0.40)

out <- as.data.frame(dat[cols], stringsAsFactors = FALSE)
for (nm in names(out)) {
  if (is.factor(out[[nm]])) out[[nm]] <- as.character(out[[nm]])
}


# =============================================================================
# 4. Write and report
# =============================================================================

write.dta(out, file = out_file)

coh <- out[out$shafi17 == 1, ]
cat("\n--- synthetic data written ---------------------------------------\n")
cat("file             :", out_file, "\n")
cat("source           :", if (learned) paste("marginals learned from", real_in)
                          else "fallback schema (no real file read)", "\n")
cat("rows x columns   :", nrow(out), "x", ncol(out), "\n")
cat("cohort (shafi17) :", nrow(coh), "patients at",
    length(unique(coh$hospid)), "hospitals\n")
cat("TTO (pref)       : range", paste(round(range(out$pref), 3), collapse = " to "),
    "| mean", round(mean(out$pref), 3),
    "| distinct values", length(unique(out$pref)), "\n")
cat("median distinct TTO values per hospital:",
    median(tapply(coh$pref, coh$hospid, function(v) length(unique(v)))), "\n")
cat("surgery rate     :", round(mean(coh$surg), 3), "\n")
cat("composite outcome:", round(mean(as.numeric(coh$died + coh$prolonged > 0)), 3), "\n")
cat("identifiers      : hospid is synthetic (1..H); no other id columns",
    if (keep_all) "-- BUT LIV_SYNTH_KEEP_ALL mirrored every real column, check before sharing"
    else "are included", "\n")
cat("------------------------------------------------------------------\n")
