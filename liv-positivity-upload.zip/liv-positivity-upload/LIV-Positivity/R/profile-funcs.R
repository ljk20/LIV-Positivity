# =============================================================================
# profile-funcs.R
#
# Influence-function-based estimators for the principal-strata covariate
# distributions of Section 5.1 (compliers, always-takers, never-takers) under
# the delta-tilted LATE framework.  Mirrors the conventions in
# late-funcs-fast.R: SuperLearner ensemble nuisance estimation, ratio-form
# gamma_A construction, lower-cased y/a/z column lookup, mclapply over the
# delta grid, and pre-allocated storage.
# =============================================================================

library(SuperLearner)
library(ranger)

# =============================================================================
# Custom SuperLearner wrappers (mirrors late-funcs-fast.R)
# =============================================================================

SL.ranger.st <- function(Y, X, newX, family, obsWeights, ...) {
  num.trees <- max(500L, ceiling(10L * sqrt(length(Y))))
  SL.ranger(Y = Y, X = X, newX = newX, family = family,
            obsWeights = obsWeights, num.trees = num.trees,
            num.threads = 1L, ...)
}

SL.glm.loglink <- function(Y, X, newX, family, obsWeights, ...) {
  df <- cbind(Y = Y, as.data.frame(X))
  fit <- tryCatch(
    glm(Y ~ ., data = df, family = gaussian(link = "log"),
        weights = obsWeights,
        start   = c(log(max(mean(Y), 1e-8)), rep(0, ncol(X)))),
    error = function(e) {
      warning("SL.glm.loglink: log-link GLM failed (", conditionMessage(e),
              "); falling back to identity link.")
      glm(Y ~ ., data = df, weights = obsWeights)
    }
  )
  pred    <- pmax(predict(fit, newdata = as.data.frame(newX), type = "response"),
                 .Machine$double.eps)
  fit_obj <- list(object = fit)
  class(fit_obj) <- "SL.glm.loglink"
  list(pred = pred, fit = fit_obj)
}

predict.SL.glm.loglink <- function(object, newdata, ...) {
  pmax(predict(object$object, newdata = as.data.frame(newdata),
               type = "response"),
       .Machine$double.eps)
}

# Register wrappers and S3 predict method into .GlobalEnv so SuperLearner's
# get() and any furrr/parallel workers can find them.
.register_sl_wrappers <- function() {
  wrappers <- list(SL.ranger.st           = SL.ranger.st,
                   SL.glm.loglink         = SL.glm.loglink,
                   predict.SL.glm.loglink = predict.SL.glm.loglink)
  for (nm in names(wrappers)) {
    if (!exists(nm, envir = .GlobalEnv, inherits = FALSE)) {
      assign(nm, wrappers[[nm]], envir = .GlobalEnv)
    }
  }
}

# =============================================================================
# Complier covariate distribution: P(V = v0 | A^{Z_delta} > A) for delta != 0.
#
# Influence-function ratio:
#   numerator   = (1 - exp(delta*Z)/alpha_delta(X)) (gamma^A_delta(X) - A) * K(V)
#   denominator = (1 - exp(delta*Z)/alpha_delta(X)) (gamma^A_delta(X) - A)
# K(V) is an indicator (discrete V) or a Gaussian kernel weight (continuous V).
# =============================================================================

#' @param dat       Data frame with columns y, a, z (case-insensitive).
#' @param x         Covariate matrix (n x p).
#' @param ind       Column index of V within x.
#' @param dis       TRUE if V is discrete; FALSE for kernel-smoothed continuous.
#' @param h         Bandwidth (continuous V only); defaults to bw.nrd(x[, ind]).
#' @param delta.seq Tilt parameter grid (scalar or vector).
#' @param x0        Target value v0.
#' @param nsplits   Cross-fitting folds (default 2).
#' @param sl.lib    SuperLearner library for gamma_A.
#' @param ncores    Cores for parallel::mclapply over delta values.
#'
#' @return Named list: est.eff, sd.
comp <- function(dat, x, ind, dis = FALSE, h = NULL, delta.seq, x0,
                 nsplits = 2,
                 sl.lib = c("SL.ranger", "SL.mean", "SL.glm"),
                 ncores = 1L) {

  .register_sl_wrappers()
  colnames(dat) <- tolower(colnames(dat))
  n <- nrow(dat)
  k <- length(delta.seq)

  if (dis) {
    kern <- as.numeric(x[, ind] == x0)
  } else {
    if (is.null(h)) h <- bw.nrd(x[, ind])
    kern <- dnorm(x[, ind] - x0, 0, sd = h)
  }

  colnames(x) <- paste0("x", seq_len(ncol(x)))
  x_df <- as.data.frame(x)
  sl.lib.alpha <- unique(c(sl.lib, "SL.glm.loglink"))

  num    <- matrix(NA_real_, nrow = n, ncol = k)
  den    <- matrix(NA_real_, nrow = n, ncol = k)
  den_if <- matrix(NA_real_, nrow = n, ncol = k)

  s <- sample(rep(seq_len(nsplits), ceiling(n / nsplits))[seq_len(n)])

  for (fold in seq_len(nsplits)) {

    train_idx <- which(s != fold)
    test_idx  <- which(s == fold)
    x_train   <- x_df[train_idx, , drop = FALSE]

    fold_fits <- parallel::mclapply(seq_len(k), function(j) {

      delta  <- delta.seq[j]
      exp_dz <- exp(delta * dat$z)

      alpha_fit <- SuperLearner(
        Y          = exp_dz[train_idx],
        X          = x_train,
        SL.library = sl.lib.alpha,
        cvControl  = list(V = 10L),
        verbose    = FALSE
      )
      alpha_hat <- predict(alpha_fit, newdata = x_df)$pred

      gammaA_fit <- SuperLearner(
        Y          = (dat$a * exp_dz)[train_idx],
        X          = x_train,
        SL.library = sl.lib,
        cvControl  = list(V = 10L),
        verbose    = FALSE
      )
      gamma_A <- predict(gammaA_fit, newdata = x_df)$pred / alpha_hat

      wt   <- 1 - exp_dz / alpha_hat
      core <- wt * (gamma_A - dat$a)

      list(
        num    = (core * kern)[test_idx],
        den    = core[test_idx],
        den_if = mean(core[test_idx])
      )

    }, mc.cores = ncores)

    for (j in seq_len(k)) {
      num[test_idx, j]    <- fold_fits[[j]]$num
      den[test_idx, j]    <- fold_fits[[j]]$den
      den_if[test_idx, j] <- fold_fits[[j]]$den_if
    }
  }

  est.eff <- numeric(k)
  sd_vec  <- numeric(k)

  for (j in seq_len(k)) {
    est.eff[j] <- mean(num[, j]) / mean(den[, j])
    ifval_j    <- (num[, j] - est.eff[j] * den[, j]) / mean(den_if[, j])
    sd_vec[j]  <- sd(ifval_j)
  }

  list(est.eff = est.eff, sd = sd_vec / sqrt(n))
}


# =============================================================================
# Always-taker covariate distribution: P(V = v0 | A^{Z_delta} = A = 1).
# Independent of delta and of nuisance estimation.
# =============================================================================
alw <- function(dat, x, ind, dis = FALSE, h = NULL, x0) {

  colnames(dat) <- tolower(colnames(dat))
  n <- nrow(dat)

  if (dis) {
    kern <- as.numeric(x[, ind] == x0)
  } else {
    if (is.null(h)) h <- bw.nrd(x[, ind])
    kern <- dnorm(x[, ind] - x0, 0, sd = h)
  }

  num     <- dat$a * kern
  den     <- dat$a
  den_if  <- mean(dat$a)
  est.eff <- mean(num) / mean(den)
  ifval   <- (num - est.eff * den) / den_if
  sd_val  <- sd(ifval)

  list(est.eff = est.eff, sd = sd_val / sqrt(n))
}


# =============================================================================
# Never-taker covariate distribution: P(V = v0 | A^{Z_delta} = A = 0).
#
# Influence-function ratio with kernel/indicator weight K(V); core is the
# (sign-flipped) uncentered IF of E[1 - gamma^A_delta(X)]:
#   core = gamma_A - (exp(delta*Z)/alpha_delta) * (gamma_A - A) - 1
# Sign cancels in the num/den ratio.
# =============================================================================
nvtk <- function(dat, x, ind, dis = FALSE, h = NULL, delta.seq, x0,
                 nsplits = 2,
                 sl.lib = c("SL.ranger", "SL.mean", "SL.glm"),
                 ncores = 1L) {

  .register_sl_wrappers()
  colnames(dat) <- tolower(colnames(dat))
  n <- nrow(dat)
  k <- length(delta.seq)

  if (dis) {
    kern <- as.numeric(x[, ind] == x0)
  } else {
    if (is.null(h)) h <- bw.nrd(x[, ind])
    kern <- dnorm(x[, ind] - x0, 0, sd = h)
  }

  colnames(x) <- paste0("x", seq_len(ncol(x)))
  x_df <- as.data.frame(x)
  sl.lib.alpha <- unique(c(sl.lib, "SL.glm.loglink"))

  num    <- matrix(NA_real_, nrow = n, ncol = k)
  den    <- matrix(NA_real_, nrow = n, ncol = k)
  den_if <- matrix(NA_real_, nrow = n, ncol = k)

  s <- sample(rep(seq_len(nsplits), ceiling(n / nsplits))[seq_len(n)])

  for (fold in seq_len(nsplits)) {

    train_idx <- which(s != fold)
    test_idx  <- which(s == fold)
    x_train   <- x_df[train_idx, , drop = FALSE]

    fold_fits <- parallel::mclapply(seq_len(k), function(j) {

      delta  <- delta.seq[j]
      exp_dz <- exp(delta * dat$z)

      alpha_fit <- SuperLearner(
        Y          = exp_dz[train_idx],
        X          = x_train,
        SL.library = sl.lib.alpha,
        cvControl  = list(V = 10L),
        verbose    = FALSE
      )
      alpha_hat <- predict(alpha_fit, newdata = x_df)$pred

      gammaA_fit <- SuperLearner(
        Y          = (dat$a * exp_dz)[train_idx],
        X          = x_train,
        SL.library = sl.lib,
        cvControl  = list(V = 10L),
        verbose    = FALSE
      )
      gamma_A <- predict(gammaA_fit, newdata = x_df)$pred / alpha_hat

      core <- gamma_A - (exp_dz / alpha_hat) * (gamma_A - dat$a) - 1

      list(
        num    = (core * kern)[test_idx],
        den    = core[test_idx],
        den_if = mean(core[test_idx])
      )

    }, mc.cores = ncores)

    for (j in seq_len(k)) {
      num[test_idx, j]    <- fold_fits[[j]]$num
      den[test_idx, j]    <- fold_fits[[j]]$den
      den_if[test_idx, j] <- fold_fits[[j]]$den_if
    }
  }

  est.eff <- numeric(k)
  sd_vec  <- numeric(k)

  for (j in seq_len(k)) {
    est.eff[j] <- mean(num[, j]) / mean(den[, j])
    ifval_j    <- (num[, j] - est.eff[j] * den[, j]) / mean(den_if[, j])
    sd_vec[j]  <- sd(ifval_j)
  }

  list(est.eff = est.eff, sd = sd_vec / sqrt(n))
}


# =============================================================================
# profile_from_fit: principal-stratum profiles from a late_fast() fit.
#
# comp(), nvtk() and alw() refit alpha_delta and gamma^A_delta for every
# target value, but those are the nuisances late_fast() already fits, and each
# stratum core is a simple function of late_fast()'s cross-fitted complier core
# den = {1 - exp(delta*Z)/alpha_delta(X)}(gamma^A_delta(X) - A):
#   compliers      core = den          (the comp() core)
#   never-takers   core = den + A - 1  (the nvtk() core, rearranged)
#   always-takers  core = A            (the alw() core; delta-free)
# For a function f of V (V a subset of X), E[f(V) | stratum] is estimated by
# mean(core * f) / mean(core), with influence values
# (core * f - est * core) / mean(core).  Indicator columns 1(V <= v) give the
# stratum CDF of V, which is root-n estimable without a bandwidth; a column
# equal to V gives the stratum mean of V.
# =============================================================================

#' @param fit    late_fast() output computed with return_if = TRUE.
#' @param a      Treatment vector, in the row order used for the fit.
#' @param K      n x m matrix whose column l holds f_l(V_i).
#' @param band   If TRUE, add a simultaneous 95% critical value across the m
#'               columns for each stratum and delta (multiplier bootstrap,
#'               standardised as in .cluster_inference() in late-funcs-fast.R).
#' @param n_boot Multiplier draws when band = TRUE.
#'
#' @return list(complier, never_taker, always_taker).  complier and
#'   never_taker hold m x k matrices est and sd (plus a length-k calpha when
#'   band = TRUE); always_taker holds length-m vectors est and sd (plus a
#'   scalar calpha).  SEs are cluster-robust whenever the fit was.
profile_from_fit <- function(fit, a, K, band = FALSE, n_boot = 10000L) {

  if (is.null(fit$den)) {
    stop("`fit` must come from late_fast(..., return_if = TRUE).",
         call. = FALSE)
  }
  K <- as.matrix(K)
  n <- nrow(fit$den)
  k <- ncol(fit$den)
  m <- ncol(K)
  if (length(a) != n || nrow(K) != n) {
    stop("`a` and `K` must have one entry per row of the fit (n = ", n, ").",
         call. = FALSE)
  }
  cluster_id <- fit$cluster_id

  # Estimates, SEs and (optionally) calpha for one stratum core.
  one <- function(core) {
    mc    <- mean(core)
    est   <- colMeans(core * K) / mc
    ifval <- (core * K - outer(core, est)) / mc
    Sg    <- rowsum(ifval, group = cluster_id, reorder = FALSE)
    G     <- nrow(Sg)
    sd    <- sqrt((G / (G - 1)) * colSums(Sg^2)) / n
    res   <- list(est = est, sd = sd)
    if (band) res$calpha <- .band_calpha(Sg, n * sd, n_boot)
    res
  }

  by_delta <- function(core_of_den) {
    blocks <- lapply(seq_len(k), function(j) one(core_of_den(fit$den[, j])))
    field  <- function(nm) {
      matrix(vapply(blocks, function(b) b[[nm]], numeric(m)),
             nrow = m, ncol = k, dimnames = list(colnames(K), NULL))
    }
    res <- list(est = field("est"), sd = field("sd"))
    if (band) res$calpha <- vapply(blocks, function(b) b$calpha, numeric(1))
    res
  }

  complier     <- by_delta(function(den) den)
  never_taker  <- by_delta(function(den) den + a - 1)
  always_taker <- one(as.numeric(a))

  list(complier = complier, never_taker = never_taker,
       always_taker = always_taker)
}

# Simultaneous 95% critical value from cluster sums Sg (G x m) of influence
# values, standardised by denom = n * sd as in .cluster_inference(), but with
# the Rademacher multipliers drawn in chunks: memory stays at G x chunk instead
# of G x n_boot (several GB per call at G = n = 123,420, n_boot = 10,000).
# The draws follow the same RNG stream, so when n_boot is a multiple of chunk
# the result equals .cluster_inference()'s calpha under the same seed.
.band_calpha <- function(Sg, denom, n_boot, chunk = 250L) {
  denom   <- ifelse(denom > 0, denom, 1)   # guard an all-zero column
  Sg_std  <- sweep(Sg, 2L, denom, "/")
  G       <- nrow(Sg)
  max_abs <- numeric(n_boot)
  for (start in seq.int(1L, n_boot, by = chunk)) {
    B    <- min(chunk, n_boot - start + 1L)
    mult <- matrix(2 * rbinom(G * B, 1L, 0.5) - 1, nrow = G, ncol = B)
    max_abs[start:(start + B - 1L)] <- apply(abs(crossprod(mult, Sg_std)), 1L, max)
  }
  unname(quantile(max_abs, 0.95))
}
