library(tidyverse)
library(foreign)
library(fixest)
library(mvtnorm)
library(ranger)
library(parallel)
library(here)

rm(list=ls())

# Reads data/iv_match_synthetic.dta unless LIV_DATA_FILE points elsewhere.
data_file <- Sys.getenv("LIV_DATA_FILE",
                        unset = here("data/iv_match_synthetic.dta"))
out_dir   <- here("output/application")
# 03_estimation-supp.R and 08_delta-sensitivity.R read these per-patient
# pieces of the fit.  They are derived from individual records, so with the
# restricted data set LIV_PIECES_FILE to a location your data agreement allows
# rather than leaving them beside the other outputs.
pieces_file <- Sys.getenv("LIV_PIECES_FILE",
                          unset = file.path(out_dir, "liv-est-pieces.RData"))

stamp <- function(what) cat(format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "--", what, "\n")
stamp("start")


# =============================================================================
# Pre-flight checks
# =============================================================================
# The run takes about 4 hours unattended, so anything it needs later is
# checked before the first fit.

# SuperLearner drops a learner whose package is missing with only a warning,
# and warnings raised inside the mclapply workers never reach this log.
stopifnot("package gam is not installed, so SL.gam would be dropped" =
            requireNamespace("gam", quietly = TRUE))

# Both output locations must be writable before the first fit.
for (d in unique(c(out_dir, dirname(pieces_file)))) {
  probe <- file.path(d, paste0(".write-probe-", Sys.getpid()))
  if (!isTRUE(file.create(probe))) stop("Cannot write to ", d, call. = FALSE)
  unlink(probe)
}


# =============================================================================
# Source dependencies
# =============================================================================
source(here("R/late-funcs-fast.R"))
source(here("R/profile-funcs.R"))
source(here("R/sensitivity_xi.R"))

# late_fast(return_if) is needed here, and profile_from_fit() / sen_from_fit()
# by 03_estimation-supp.R.
stopifnot("R/ does not hold the estimator versions this pipeline needs" =
            "return_if" %in% names(formals(late_fast)) &&
            exists("profile_from_fit") && exists("sen_from_fit"))

# Override SL.ranger.st with a fixed, smaller num.trees (no n-adaptive scaling).
# The wrapper registrations inside late_fast / comp / nvtk / sen use an
# `exists(..., inherits = FALSE)` guard, so this .GlobalEnv definition wins.
SL.ranger.st <- function(Y, X, newX, family, obsWeights, ...) {
  SL.ranger(Y = Y, X = X, newX = newX, family = family,
            obsWeights = obsWeights, num.trees = 250L,
            num.threads = 1L, ...)
}

# Pitfall #10 update (2026-05-12): the `.patch_alpha` AST override that
# previously lived here has been removed.  The Triage-Delta-Sweep.R results
# showed it was insufficient at delta >= 6.2 and strictly worse than the
# unpatched pipeline at delta in {8.1, 10}.  The chosen remediation is to
# restrict the delta grid to a range where the unpatched SL pipeline matches
# the legacy ranger-only baseline (see delta.seq below).  See Pitfall #10
# for the full history.

cat("Reading data from:", data_file, "\n")
data <- read.dta(data_file)

data.1 <- data %>% filter(shafi17==1)
data.1$outcome <- as.numeric(data.1$died + data.1$prolonged > 0)
nrow(data.1)
table(data.1$outcome)

setFixest_estimation(fixef.rm = "none")

feols_model <- feols(outcome ~ 1 | hospid, data = data.1)
data.1$purge <- feols_model$residuals


vars <- c("comorb", "angus", "age","ynel1","ynel2","ynel3","ynel4", "ynel5",
            "ynel6","ynel7","ynel8","ynel9","ynel10","ynel11","ynel12","ynel13",
            "ynel14","ynel15","ynel16","ynel17","ynel18","ynel19","ynel20","ynel21",
            "ynel22","ynel23","ynel24","ynel25","ynel26","ynel27","ynel28",
            "ynel29","ynel30", "ynel31", "p_cat1", "p_cat2", "p_cat3","p_cat4",
            "p_cat5", "female", "hisp", "afam", "other", "disability_bin")

  y <- data.1$purge;
  a <- data.1$surg;
  z <- data.1$pref
  dat <- as.data.frame(cbind(y,a,z))
  x <- as.matrix(data.1[,vars])
  n <- dim(dat)[1]
  # Pitfall #10: delta upper bound shortened from 6 to 4.5 after the
  # seq(.5, 6) run produced comp.eff = 2.41 at delta = 6 (impossible —
  # signals the SL alpha-hat IF blowup).  Sweep certified clean only
  # through 4.3; 4.5 is the next-grid-point probe above that.  Revisit
  # if comp.eff leaves [0, 1] anywhere in this grid.
  delta.seq <- seq(.5, 4.5, length = 6)
  nsplits   <- 2
  ncores    <- min(6L, max(1L, parallel::detectCores() - 1L))
  sl.lib    <- c("SL.ranger.st", "SL.gam", "SL.glm")

# Reproducible folds, SuperLearner CV splits, and bootstrap draws, including
# inside the mclapply workers.
RNGkind("L'Ecuyer-CMRG")
set.seed(20260914)

stamp(sprintf("late_fast (n = %d, ncores = %d)", n, ncores))
mod <- late_fast(
    dat       = dat,
    x         = x,
    delta.seq = delta.seq,
    nsplits   = nsplits,
    sl.lib    = sl.lib,
    ncores    = ncores,
    n_boot    = 10000L,
    return_if = TRUE)

# 03_estimation-supp.R derives the stratum profiles and the monotonicity
# sensitivity grids from these cross-fitted pieces instead of refitting.
# `check` lets it confirm it rebuilt the same cohort in the same row order.
pieces <- list(den        = mod$den,
               ifval      = mod$ifval,
               cluster_id = mod$cluster_id,
               delta.seq  = delta.seq,
               n          = n,
               check      = c(sum_a = sum(a), wsum_z = sum(z * seq_len(n))))
mod[c("den", "ifval", "cluster_id")] <- NULL

save(mod, n, file = file.path(out_dir, "liv-est.RData"))

# The pieces are written under a temporary name and read back before being
# renamed, so an interrupted write never leaves a complete-looking file.
save_pieces <- function(pieces, file) {
  tmp <- paste0(file, ".partial")
  ok <- tryCatch({
    save(pieces, file = tmp)
    back <- new.env()
    load(tmp, envir = back)
    identical(back$pieces, pieces) && file.rename(tmp, file)
  }, error = function(e) {
    message(conditionMessage(e))
    FALSE
  })
  if (!ok) stamp(paste("could not save the per-patient pieces to", file))
  ok
}
pieces_saved <- save_pieces(pieces, pieces_file)

stamp("late_delta_0_fast")
mod.0 <- late_delta_0_fast(
    dat       = dat,
    x         = x,
    nsplits   = nsplits,
    sl.lib    = sl.lib)

save(mod, mod.0, n, file = file.path(out_dir, "liv-est.RData"))

stamp("iv_mean_fast")
# alpha_floor keeps alpha-hat at or above exp(delta * min Z), the smallest
# value E[exp(delta Z) | X] can take.  Without it the 2026-09-14 run gave a
# mean TTO of 1.540 at delta = 4.5 -- impossible, since TTO <= 1 -- because one
# patient's alpha-hat came out at -0.0059 in one fold (IV-Mean-Diagnostic.R).
# It binds only there: every other delta was unchanged to four decimals
# (IV-Mean-Refit.R, which repaired the saved estimates).
mod.mean <- iv_mean_fast(
    dat         = dat,
    x           = x,
    delta.seq   = delta.seq,
    nsplits     = nsplits,
    sl.lib      = sl.lib,
    ncores      = ncores,
    alpha_floor = TRUE)

save(mod, mod.0, mod.mean, n, file = file.path(out_dir, "liv-est.RData"))
stamp("estimates saved")


# =============================================================================
# Summary for the run log
# =============================================================================

print(round(data.frame(delta = delta.seq, est = mod$est.eff, plug = mod$est.plug,
                       sd = mod$sd, comp = mod$comp.eff, tto = mod.mean$est), 4))
cat(sprintf("uniform-band critical value %.2f; psi(0+) = %.4f (SE %.4f)\n",
            mod$calpha, mod.0$est.eff, mod.0$sd))
# Pitfall #10 tripwire: the complier share must lie strictly inside (0, 1).
if (any(mod$comp.eff <= 0 | mod$comp.eff >= 1)) {
  cat("WARNING: complier share outside (0, 1) -- see CLAUDE.md Pitfall #10\n")
}
sessionInfo()

if (!pieces_saved) {
  stop("liv-est.RData is complete, but the per-patient pieces were not saved to ",
       pieces_file, ", so 03_estimation-supp.R cannot run.", call. = FALSE)
}
stamp("done; per-patient pieces saved")

# Profiling (sepsis + age) and the monotonicity sensitivity grids live in
# 03_estimation-supp.R, which reads the pieces file and liv-est.RData.
