# =============================================================================
# Figure 4: positivity diagnostics for the TTO application.
#
# The argument: patient covariates alone create no positivity problem, but a
# patient can only be treated by the surgeons at their hospital, so any TTO
# value that no surgeon there has is structurally unavailable to them.
#
# Left: for each patient, the lowest estimated conditional density of TTO
#   given patient covariates over the 5th-95th percentile TTO grid.  If it is
#   bounded away from zero, patient covariates alone do not create a
#   positivity problem.
# Middle: each hospital's TTO range (lowest to highest TTO among the surgeons
#   of its cholecystitis patients), sorted by highest TTO.  TTO values above a
#   hospital's highest are unavailable there, which matters for delta > 0.
# Right: for each patient, the longest stretch of the grid's TTO range with no
#   surgeon at their hospital, counting the stretches below the hospital's
#   lowest and above its highest TTO.  Every TTO value in that stretch is
#   unavailable to the patient; no smoothing is involved.
#
# Comparison figure (tto_positivity_gaps.pdf; for the response, not the
#   paper): the right panel's measure against the minimum of a hospital-only
#   kernel density over the same grid, which depends on the bandwidth.
#
# Inputs : output/application/positivity.RData (01_density-estimation.R)
#          output/application/liv-est.RData    (mod.mean from 02_estimation.R) — used only
#          for the printed tilt-mean shares below; nothing is drawn from it.
# Outputs: figures/application/tto_positivity.pdf, figures/application/tto_positivity_gaps.pdf
# =============================================================================

library(ggplot2)
library(here)
library(patchwork)

rm(list = ls())

load(here("output/application/positivity.RData"))
load(here("output/application/liv-est.RData"))

# Mean TTO under the smallest and largest tilts.  These are not drawn on the
# figure (the lines were dropped 2026-09-16); they only scale the printed
# shares of patients whose hospital cannot reach each tilt mean.
tilt_means <- range(mod.mean$est)

pct <- scales::label_percent(accuracy = 1)

# Left: lowest density given patient covariates ------------------------------
p1 <- ggplot(data.frame(v = min_dens_x), aes(v)) +
  geom_histogram(bins = 50, fill = "gray75", colour = "white") +
  geom_vline(xintercept = 0, linewidth = 0.5) +
  labs(x = expression(min[z] ~ hat(pi)(z ~ "|" ~ bold(X)[i])),
       y = "Patients")

# Middle: hospital TTO ranges -------------------------------------------------
p2 <- ggplot(hosp, aes(x = rank)) +
  geom_linerange(aes(ymin = tto_min, ymax = tto_max),
                 colour = "gray60", linewidth = 0.3) +
  geom_point(aes(y = tto_max), size = 0.4) +
  scale_y_continuous(labels = pct, limits = c(0, 1)) +
  labs(x = "Hospitals, sorted by highest TTO", y = "TTO")

# Right: longest TTO stretch with no surgeon at the patient's hospital -------
p3 <- ggplot(data.frame(v = max_uncov_hosp), aes(v)) +
  geom_histogram(bins = 50, fill = "gray75", colour = "white") +
  geom_vline(xintercept = 0, linewidth = 0.5) +
  scale_x_continuous(labels = pct) +
  labs(x = "Longest TTO stretch with no surgeon\nat the patient's hospital",
       y = "Patients")

# patchwork keeps the three panels aligned.
fig4 <- (p1 | p2 | p3) &
  theme_bw(base_size = 15)

ggsave(here("figures/application/tto_positivity.pdf"), fig4,
       width = 14, height = 5)

# Comparison: density minimum vs. the direct measure --------------------------
c1 <- ggplot(data.frame(v = min_dens_hosp), aes(v)) +
  geom_histogram(bins = 50, fill = "gray75", colour = "white") +
  geom_vline(xintercept = 0, linewidth = 0.5) +
  labs(x = "Lowest hospital-only density\nover the TTO grid", y = "Patients")

c2 <- p3

c3 <- ggplot(hosp, aes(max_uncov, min_dens)) +
  geom_point(aes(size = n_pat), shape = 1, alpha = 0.5) +
  scale_size_area(name = "Patients", max_size = 4) +
  scale_x_continuous(labels = pct) +
  labs(x = "Longest TTO stretch with no surgeon",
       y = "Lowest hospital-only density")

ggsave(here("figures/application/tto_positivity_gaps.pdf"),
       (c1 | c2 | c3) + plot_layout(guides = "collect") &
         theme_bw(base_size = 14) & theme(legend.position = "bottom"),
       width = 15, height = 5)

# Summary printouts for the paper text ----------------------------------------
share_below <- function(v, cut) 100 * mean(v < cut)
pat_share   <- function(keep) 100 * sum(hosp$n_pat[keep]) / sum(hosp$n_pat)

cat(sprintf("TTO grid: %.3f to %.3f (%d points, 5th-95th percentiles)\n",
            min(z.grid), max(z.grid), length(z.grid)))
cat(sprintf(
  "Left: lowest density given patient covariates -- min %.3f, 1st pct %.3f, median %.3f; below 0.05: %.2f%% of patients\n",
  min(min_dens_x), quantile(min_dens_x, 0.01), median(min_dens_x),
  share_below(min_dens_x, 0.05)))
cat(sprintf(
  "Middle: %d hospitals; median TTO range width %.2f; median %d distinct TTO values per hospital; %d hospitals (%.1f%% of patients) have a single TTO value\n",
  nrow(hosp), median(hosp$tto_max - hosp$tto_min), as.integer(median(hosp$n_tto)),
  sum(hosp$n_tto == 1), pat_share(hosp$n_tto == 1)))
cat(sprintf(
  "Middle: patients whose hospital's highest TTO is below the smallest-tilt mean (%.1f%%): %.1f%%; below the largest-tilt mean (%.1f%%): %.1f%%\n",
  100 * tilt_means[1], pat_share(hosp$tto_max < tilt_means[1]),
  100 * tilt_means[2], pat_share(hosp$tto_max < tilt_means[2])))
cat(sprintf(
  "Right: longest TTO stretch with no surgeon -- patient median %.3f; longer than 0.10: %.1f%%, 0.20: %.1f%% of patients\n",
  median(max_uncov_hosp), 100 * mean(max_uncov_hosp > 0.10),
  100 * mean(max_uncov_hosp > 0.20)))
cat(sprintf(
  "Comparison: hospital-only density minimum below 0.05 for %.1f%% of patients (TTO bandwidth %.3f); Spearman correlation with the right panel's measure across hospitals %.2f\n",
  share_below(min_dens_hosp, 0.05), bw_tto,
  cor(hosp$max_uncov, hosp$min_dens, method = "spearman")))
