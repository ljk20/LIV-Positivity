# =============================================================================
# Density-Estimation.R — positivity diagnostics for the TTO application.
#
# The argument in Section 7: given patient covariates alone, the conditional
# density of TTO is bounded away from zero, so they do not create a positivity
# problem; hospitals do, because a patient can only be treated by the surgeons
# at their hospital.  For the cholecystitis cohort this script computes:
#   1. for each patient, the minimum over a grid of TTO values of
#      pi_hat(z | patient covariates).  The density at a patient's own TTO
#      says nothing about other TTO values (Round 3 AE comment 1).  Hospital
#      is deliberately not conditioned on here.
#   2. each hospital's TTO range, with hospitals anonymised by rank.
#   3. the same per-patient minimum under a hospital-only kernel density, as
#      a like-for-like contrast with 1, and its bandwidth-free counterpart:
#      the longest stretch of the grid's TTO range with no surgeon at the
#      patient's hospital.
# Writes output/application/positivity.RData for 04_figure-4.R.
# =============================================================================

library(foreign)
library(np)
library(dplyr)
library(here)

rm(list = ls())

# Reads data/iv_match_synthetic.dta unless LIV_DATA_FILE points elsewhere.
DATA_FILE <- Sys.getenv("LIV_DATA_FILE", unset = here("data/iv_match_synthetic.dta"))
out_dir   <- here("output/application")
cat("Reading data from:", DATA_FILE, "\n")

data.1 <- read.dta(DATA_FILE) %>% filter(shafi17 == 1)

vars <- c("comorb", "angus", "age", "ynel1", "ynel2", "ynel3", "ynel4", "ynel5",
          "ynel6", "ynel7", "ynel8", "ynel9", "ynel10", "ynel11", "ynel12",
          "ynel13", "ynel14", "ynel15", "ynel16", "ynel17", "ynel18", "ynel19",
          "ynel20", "ynel21", "ynel22", "ynel23", "ynel24", "ynel25", "ynel26",
          "ynel27", "ynel28", "ynel29", "ynel30", "ynel31", "p_cat1", "p_cat2",
          "p_cat3", "p_cat4", "p_cat5", "female", "hisp", "afam", "other",
          "disability_bin")

z <- data.1$pref
X <- as.data.frame(data.1[, vars])
n <- length(z)

# Relevant TTO values: the 5th to 95th percentiles of the cohort's TTO
# distribution.  The extremes are left out because kernel estimates are
# biased downward at the edges of the support.
z.grid <- unname(quantile(z, seq(0.05, 0.95, by = 0.05)))


# =============================================================================
# 1. pi(z | patient covariates)
# =============================================================================
# Single-index model: Z is regressed on the patient covariates by OLS, and the
# density of Z is estimated conditional on that linear index with
# normal-reference bandwidths.  The estimate is evaluated on (TTO grid x index
# grid) and interpolated along the index for each patient, instead of
# evaluating n x length(z.grid) points against n training points.

mhat <- as.numeric(fitted(lm(z ~ ., data = data.frame(z = z, X))))
bw   <- npcdensbw(z ~ mhat, data = data.frame(z = z, mhat = mhat),
                  bwmethod = "normal-reference")
summary(bw)

m.grid   <- unique(unname(quantile(mhat, seq(0, 1, length.out = 401))))
eval_pts <- expand.grid(z = z.grid, mhat = m.grid)   # z varies fastest
cde_grid <- npcdens(bws   = bw,
                    exdat = data.frame(mhat = eval_pts$mhat),
                    eydat = data.frame(z = eval_pts$z))
dens_grid <- matrix(fitted(cde_grid), nrow = length(z.grid))   # z.grid x m.grid

dens_x <- vapply(seq_along(z.grid), function(r) {
  approx(m.grid, dens_grid[r, ], xout = mhat, rule = 2)$y
}, numeric(n))                                        # n x length(z.grid)
min_dens_x <- apply(dens_x, 1, min)


# =============================================================================
# 2. Hospital TTO ranges
# =============================================================================
# A patient's TTO cannot fall outside the range of TTO among the surgeons
# treating cholecystitis patients at their hospital.

hosp <- data.1 %>%
  group_by(hospid) %>%
  summarize(n_pat   = n(),
            n_tto   = n_distinct(pref),
            tto_min = min(pref),
            tto_med = median(pref),
            tto_max = max(pref),
            .groups = "drop") %>%
  arrange(tto_max, tto_min) %>%
  mutate(rank = row_number())


# =============================================================================
# 3. pi(z | hospital)
# =============================================================================
# Hospital-only Gaussian kernel density on the same TTO grid, with the TTO
# bandwidth from model 1, so the two per-patient minima differ only in what
# they condition on.

bw_tto <- bw$ybw
dens_h <- t(vapply(split(z, data.1$hospid), function(zh) {
  colMeans(dnorm(outer(zh, z.grid, "-") / bw_tto)) / bw_tto
}, numeric(length(z.grid))))                          # hospitals x length(z.grid)
min_dens_by_hosp <- apply(dens_h, 1, min)

min_dens_hosp <- unname(min_dens_by_hosp[as.character(data.1$hospid)])
hosp$min_dens <- unname(min_dens_by_hosp[as.character(hosp$hospid)])

# Direct, bandwidth-free counterpart: the longest stretch of the grid's TTO
# range [min(z.grid), max(z.grid)] that no surgeon at the hospital covers,
# counting the stretches below its lowest and above its highest TTO.  At a
# hospital, any TTO value in that stretch has zero probability.
longest_uncovered <- function(zh, lo = min(z.grid), hi = max(z.grid)) {
  inside <- sort(unique(zh[zh >= lo & zh <= hi]))
  max(diff(c(lo, inside, hi)))
}
uncov_by_hosp <- vapply(split(z, data.1$hospid), longest_uncovered, numeric(1))

max_uncov_hosp <- unname(uncov_by_hosp[as.character(data.1$hospid)])
hosp$max_uncov <- unname(uncov_by_hosp[as.character(hosp$hospid)])

# Drop the hospital identifier before saving; rank identifies rows.
hosp      <- hosp %>% select(-hospid)
bw_index  <- bw$xbw

save(z.grid, min_dens_x, min_dens_hosp, max_uncov_hosp, hosp, bw_index,
     bw_tto, n, file = file.path(out_dir, "positivity.RData"))
