# =============================================================================
# 03_estimation-supp.R — supplementary application analyses for paper 1.
#
# Principal-stratum profiles (sepsis prevalence; the distribution function and
# mean of age) and the monotonicity sensitivity grids at both ends of the
# delta grid.  Everything is derived from the main late_fast() fit in
# Estimation.R, which must be run first: it saves the fit's per-patient
# cross-fitted pieces next to the restricted data, and profile_from_fit() /
# sen_from_fit() turn them into estimates without refitting any nuisance
# model (see CLAUDE.md).  The multiplier bootstrap for the age-CDF bands is
# the only slow step (minutes, not days).
# =============================================================================

library(dplyr)
library(foreign)
library(here)

rm(list = ls())

data_file   <- Sys.getenv("LIV_DATA_FILE",
                          unset = here("data/iv_match_synthetic.dta"))
out_dir     <- here("output/application")
pieces_file <- Sys.getenv("LIV_PIECES_FILE",
                          unset = file.path(out_dir, "liv-est-pieces.RData"))

source(here("R/late-funcs-fast.R"))
source(here("R/profile-funcs.R"))    # profile_from_fit()
source(here("R/sensitivity_xi.R"))   # sen_from_fit()

cat("Reading data from:", data_file, "\n")
data   <- read.dta(data_file)
data.1 <- data %>% filter(shafi17 == 1)
a      <- data.1$surg
z      <- data.1$pref
n      <- nrow(data.1)


# =============================================================================
# Rebuild the fit
# =============================================================================
# Aggregate estimates come from liv-est.RData and per-patient pieces from
# pieces_file.  Stop unless both belong to this cohort, in this row order.

est <- new.env()
load(file.path(out_dir, "liv-est.RData"), envir = est)
load(pieces_file)

stopifnot(
  pieces$n == n,
  isTRUE(all.equal(pieces$check,
                   c(sum_a = sum(a), wsum_z = sum(z * seq_len(n))))),
  isTRUE(all.equal(colMeans(pieces$den), est$mod$comp.eff))
)

fit       <- c(est$mod, pieces[c("den", "ifval", "cluster_id")])
delta.seq <- pieces$delta.seq
k         <- length(delta.seq)
cat(format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
    "-- data volume no longer needed (the VPN can be turned off)\n")

set.seed(20260914)   # multiplier bootstrap for the age-CDF bands


# =============================================================================
# Sepsis Profile Estimates
# =============================================================================

sepsis <- profile_from_fit(fit, a, cbind(sepsis = as.numeric(data.1$angus == 1)))

# Same shapes as the comp() / nvtk() / alw() outputs that Figure-S6.R reads.
comp.out <- list(est.eff = sepsis$complier$est[1, ],
                 sd      = sepsis$complier$sd[1, ])
nt.out   <- list(est.eff = sepsis$never_taker$est[1, ],
                 sd      = sepsis$never_taker$sd[1, ])
at.out   <- list(est.eff = unname(sepsis$always_taker$est),
                 sd      = unname(sepsis$always_taker$sd))

save(comp.out, nt.out, at.out, delta.seq,
     file = file.path(out_dir, "sepsis-profile.RData"))


# =============================================================================
# Age Profile Estimates
# =============================================================================
# Distribution function of age by stratum, replacing the kernel-smoothed
# density (Round 3 AE comment 2): indicators 1(age <= v) give a root-n target
# with no bandwidth, plus a simultaneous band across the age grid for each
# stratum and delta.  Mean age by stratum is the global summary.

age      <- data.1$age
age.grid <- seq(20, 95, by = 1)
K_cdf    <- 1 * outer(age, age.grid, "<=")
colnames(K_cdf) <- paste0("age_le_", age.grid)

age.cdf  <- profile_from_fit(fit, a, K_cdf, band = TRUE, n_boot = 10000L)
age.mean <- profile_from_fit(fit, a, cbind(age = age))

save(age.grid, age.cdf, age.mean, delta.seq,
     file = file.path(out_dir, "age-profile.RData"))


# =============================================================================
# Monotonicity Sensitivity Grids
# =============================================================================
# xi_hat = psi_hat(delta) + gamma_1 * gamma_2 / e_c(delta) follows directly
# from the main fit, so each grid's origin equals the main estimate.  The
# `delta` column holds P(Defier), not the tilt (legacy name that
# Figure-S7.R's loader expects).

defier.grid <- seq(0, 0.1, length.out = 10)
eps.grid    <- seq(0.0, 0.1, length.out = 10)
defier.seq  <- rep(defier.grid, length(eps.grid))
eps.seq     <- rep(eps.grid, each = length(defier.grid))
g1.g2       <- defier.seq * eps.seq

sens_grid <- function(j) {
  xi <- sen_from_fit(fit, g1.g2, j)
  data.frame(delta = defier.seq, eps = eps.seq, level = xi$xi_hat, se = xi$se)
}

df_tilt_low  <- sens_grid(1)
df_tilt_high <- sens_grid(k)

save(df_tilt_low,
     file = file.path(out_dir, sprintf("Mono-Sens-Delta-%.2f.RData", delta.seq[1])))
save(df_tilt_high,
     file = file.path(out_dir, sprintf("Mono-Sens-Delta-%.2f.RData", delta.seq[k])))


# =============================================================================
# Summary printouts
# =============================================================================

for (j in c(1, k)) {
  cat(sprintf(
    "delta = %.2f | sepsis: compliers %.1f%%, never-takers %.1f%% | mean age: compliers %.1f, never-takers %.1f\n",
    delta.seq[j], 100 * comp.out$est.eff[j], 100 * nt.out$est.eff[j],
    age.mean$complier$est[1, j], age.mean$never_taker$est[1, j]))
}
cat(sprintf("always-takers: sepsis %.1f%%, mean age %.1f\n",
            100 * at.out$est.eff, age.mean$always_taker$est))
cat(sprintf("mono-sens delta = %.2f: origin %.2f%%, corner %.2f%%\n",
            delta.seq[c(1, k)],
            100 * c(df_tilt_low$level[1], df_tilt_high$level[1]),
            100 * c(tail(df_tilt_low$level, 1), tail(df_tilt_high$level, 1))),
    sep = "")
