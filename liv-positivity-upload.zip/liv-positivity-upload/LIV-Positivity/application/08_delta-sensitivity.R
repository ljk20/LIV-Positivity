# =============================================================================
# Delta45-Sensitivity.R — how much a few patients move psi-hat(delta)
#
# Decision 2026-09-16: keep delta = 4.5 in the grid, and say in the text how
# sensitive the estimate there is to individual patients.  IV-Mean-Diagnostic.R
# found one patient holding 10.5% of the squared influence at delta = 4.5
# (1.0% at 3.7, under 0.5% below that), the same alpha-hat fragility that
# broke the mean TTO.  This script turns that into numbers for the text.
#
# It drops the k patients with the largest |influence| and recomputes
# psi-hat exactly, holding the nuisance fits of the run fixed.  That is
# possible from the saved pieces alone: late_fast's influence values are
#   ifval = (num - est * den) / mean(den),
# so num = ifval * mean(den) + est * den recovers the numerator, and
# mean(num) / mean(den) over any subset is the estimator on that subset.
# No refitting, so this takes seconds; the reported shifts are exact for
# those fits rather than first-order approximations.
#
# Aggregates only are saved.  The data volume is needed for the pieces file,
# but only for a moment at the start.
#
# Inputs : output/application/liv-est-pieces.RData; output/application/liv-est.RData
# Output : output/application/delta-sensitivity.RData, plus the table in the log
# =============================================================================

library(here)

rm(list = ls())
options(width = 200)

out_dir  <- here("output/application")
pieces_file <- Sys.getenv("LIV_PIECES_FILE",
                          unset = file.path(out_dir, "liv-est-pieces.RData"))

load(pieces_file)
est <- new.env()
load(file.path(out_dir, "liv-est.RData"), envir = est)

delta.seq <- pieces$delta.seq
k_grid    <- c(0L, 1L, 10L, 100L)   # patients dropped
n         <- pieces$n

rows <- do.call(rbind, lapply(seq_along(delta.seq), function(j) {

  den     <- pieces$den[, j]
  ifval   <- pieces$ifval[, j]
  est_j   <- est$mod$est.eff[j]
  mean_d  <- est$mod$comp.eff[j]
  num     <- ifval * mean_d + est_j * den

  # The reconstruction must return the saved estimate.
  stopifnot(isTRUE(all.equal(mean(num) / mean(den), est_j, tolerance = 1e-12)))

  drop_order <- order(abs(ifval), decreasing = TRUE)
  do.call(rbind, lapply(k_grid, function(k) {
    keep   <- if (k == 0L) seq_len(n) else
                setdiff(seq_len(n), drop_order[seq_len(k)])
    est_k  <- mean(num[keep]) / mean(den[keep])
    if_k   <- (num[keep] - est_k * den[keep]) / mean(den[keep])
    data.frame(delta      = delta.seq[j],
               dropped    = k,
               est_pp     = 100 * est_k,
               shift_pp   = 100 * (est_k - est_j),
               se_pp      = 100 * sd(if_k) / sqrt(length(keep)),
               comp_pct   = 100 * mean(den[keep]),
               if2_share  = if (k == 0L) NA_real_ else
                 sum(sort(ifval^2, decreasing = TRUE)[seq_len(k)]) / sum(ifval^2))
  }))
}))

cat("psi-hat(delta) after dropping the most influential patients",
    "(nuisance fits held fixed)\n")
cat("if2_share: share of the total squared influence held by the patients dropped\n\n")
print(rows, digits = 4, row.names = FALSE)

save(rows, delta.seq, k_grid, file = file.path(out_dir, "delta-sensitivity.RData"))
