# =============================================================================
# Figure S6: Principal-stratum profile diagnostics for the cholecystitis
# application.
#
# Panel A (sepsis-profile.pdf): Pr(Sepsis = 1) for compliers vs. never-takers
#   plotted against delta.  Shows whether principal-stratum membership shifts
#   sepsis prevalence as delta tilts the population toward higher surgeon TTO.
# Panel B (age-profile-1.pdf): mean age of compliers vs. never-takers plotted
#   against delta.  The dashed line is the always-taker mean, which does not
#   depend on delta.
# Panel C (age-profile-2.pdf): distribution function of age for compliers,
#   never-takers and always-takers at the median delta in the grid.
#
# The age panels replace the kernel-smoothed age density (Round 3 AE comment
# 2): the distribution function and the mean are root-n estimable without a
# bandwidth.
#
# Inputs : output/application/sepsis-profile.RData (comp.out, nt.out, at.out, delta.seq
#                                        from 03_estimation-supp.R)
#          output/application/age-profile.RData    (age.grid, age.cdf, age.mean, delta.seq)
# Outputs: figures/application/figures/sepsis-profile.pdf, figures/application/figures/age-profile-1.pdf,
#          figures/application/figures/age-profile-2.pdf
#
# - Error bars in Panels A and B are POINTWISE 95% normal CIs
#   (est +/- 1.96 * sd), not the uniform bands used in Figure-5.R.
# - Panel C's bands are SIMULTANEOUS across the age grid
#   (est +/- calpha * sd).  The estimate and both band limits are
#   rearranged into non-decreasing order (Chernozhukov, Fernandez-Val and
#   Galichon, 2009, Biometrika), which keeps the band's coverage, and clipped
#   to [0, 1].
# =============================================================================

library(ggplot2)
library(here)

rm(list = ls())

# Data-driven y-limits with 5% padding (matches Figure-5.R).
pad_ylim <- function(lower, upper) {
  r <- range(c(lower, upper))
  r + c(-1, 1) * 0.05 * diff(r)
}

# Panel A: Pr(Sepsis = 1) for compliers vs. never-takers across delta --------
# The delta grid comes from the saved outputs, so it cannot drift from the
# grid used in estimation.
load(here("output/application/sepsis-profile.RData"))
n.delta <- length(delta.seq)

df_sepsis <- data.frame(
  delta    = c(delta.seq, delta.seq),
  pe       = c(comp.out$est.eff, nt.out$est.eff),
  lcl      = c(comp.out$est.eff - 1.96 * comp.out$sd,
               nt.out$est.eff   - 1.96 * nt.out$sd),
  ucl      = c(comp.out$est.eff + 1.96 * comp.out$sd,
               nt.out$est.eff   + 1.96 * nt.out$sd),
  contrast = factor(rep(c(1, 2), each = n.delta),
                    levels = c(1, 2),
                    labels = c("Compliers", "Never-Takers"))
)

ylim_sepsis <- pad_ylim(df_sepsis$lcl, df_sepsis$ucl)

p1 <- ggplot(df_sepsis, aes(delta, shape = contrast)) +
  geom_point(aes(y = pe), size = 3) +
  geom_errorbar(aes(ymin = lcl, ymax = ucl), width = 0.2, linewidth = 0.6) +
  coord_cartesian(ylim = ylim_sepsis) +
  scale_y_continuous(labels = scales::label_percent(accuracy = 0.1)) +
  scale_shape_manual(name = "Principal Stratum", values = c(4, 5)) +
  xlab(expression(delta)) +
  ylab("Pr(Sepsis = 1)") +
  theme_bw(base_size = 18) +
  theme(legend.position = "top")

p1

ggsave(here("figures/application/sepsis-profile.pdf"), p1,
       width = 8, height = 6)

# Panel B: mean age of compliers vs. never-takers across delta ---------------
load(here("output/application/age-profile.RData"))

df_age_mean <- data.frame(
  delta    = c(delta.seq, delta.seq),
  pe       = c(age.mean$complier$est[1, ], age.mean$never_taker$est[1, ]),
  sd       = c(age.mean$complier$sd[1, ],  age.mean$never_taker$sd[1, ]),
  contrast = factor(rep(c(1, 2), each = n.delta),
                    levels = c(1, 2),
                    labels = c("Compliers", "Never-Takers"))
)
df_age_mean$lcl <- df_age_mean$pe - 1.96 * df_age_mean$sd
df_age_mean$ucl <- df_age_mean$pe + 1.96 * df_age_mean$sd
at_mean <- unname(age.mean$always_taker$est)

ylim_age_mean <- pad_ylim(c(df_age_mean$lcl, at_mean),
                          c(df_age_mean$ucl, at_mean))
dodge <- position_dodge(width = 0.3)

p2 <- ggplot(df_age_mean, aes(delta, shape = contrast)) +
  geom_hline(data = data.frame(at_mean = at_mean),
             aes(yintercept = at_mean, linetype = "Always-Takers"),
             colour = "gray40") +
  geom_point(aes(y = pe), size = 3, position = dodge) +
  geom_errorbar(aes(ymin = lcl, ymax = ucl), width = 0.2, linewidth = 0.6,
                position = dodge) +
  coord_cartesian(ylim = ylim_age_mean) +
  scale_shape_manual(name = "Principal Stratum", values = c(4, 5)) +
  scale_linetype_manual(name = NULL, values = "dashed") +
  xlab(expression(delta)) +
  ylab("Mean Age (years)") +
  theme_bw(base_size = 18) +
  theme(legend.position = "top")

p2

ggsave(here("figures/application/age-profile-1.pdf"), p2,
       width = 8, height = 6)

# Panel C: distribution function of age at the median delta -----------------
delta_idx <- ceiling(n.delta / 2)
delta_val <- delta.seq[delta_idx]

clip01 <- function(v) pmin(pmax(v, 0), 1)
cdf_curve <- function(est, sd, calpha, label) {
  data.frame(age     = age.grid,
             pe      = clip01(sort(est)),
             lcl     = clip01(sort(est - calpha * sd)),
             ucl     = clip01(sort(est + calpha * sd)),
             stratum = label)
}

df_cdf <- rbind(
  cdf_curve(age.cdf$complier$est[, delta_idx], age.cdf$complier$sd[, delta_idx],
            age.cdf$complier$calpha[delta_idx], "Compliers"),
  cdf_curve(age.cdf$never_taker$est[, delta_idx], age.cdf$never_taker$sd[, delta_idx],
            age.cdf$never_taker$calpha[delta_idx], "Never-Takers"),
  cdf_curve(age.cdf$always_taker$est, age.cdf$always_taker$sd,
            age.cdf$always_taker$calpha, "Always-Takers")
)
df_cdf$stratum <- factor(df_cdf$stratum,
                         levels = c("Compliers", "Never-Takers", "Always-Takers"))

p3 <- ggplot(df_cdf, aes(age, pe, linetype = stratum)) +
  geom_ribbon(aes(ymin = lcl, ymax = ucl, fill = stratum),
              alpha = 0.2, colour = NA) +
  geom_line(linewidth = 0.7) +
  scale_linetype_manual(name = "Principal Stratum",
                        values = c("solid", "dashed", "dotted")) +
  scale_fill_manual(name = "Principal Stratum",
                    values = c("gray20", "gray50", "gray80")) +
  scale_y_continuous(labels = scales::label_percent(accuracy = 1)) +
  xlab("Age (years)") +
  ylab(expression(Pr(Age <= a))) +
  theme_bw(base_size = 18) +
  theme(legend.position = "top")

p3

ggsave(here("figures/application/age-profile-2.pdf"), p3,
       width = 8, height = 6)

# Summary printouts for the paper text ---------------------------------------
cat(sprintf(
  "Panel A (sepsis): Pr(Sepsis = 1) at delta = %.2f -- compliers %.2f%%, never-takers %.2f%%\n",
  delta.seq[c(1, n.delta)], 100 * comp.out$est.eff[c(1, n.delta)],
  100 * nt.out$est.eff[c(1, n.delta)]), sep = "")

cat(sprintf(
  "Panel B (mean age): delta = %.2f -- compliers %.1f (SE %.2f), never-takers %.1f (SE %.2f)\n",
  delta.seq[c(1, n.delta)],
  age.mean$complier$est[1, c(1, n.delta)], age.mean$complier$sd[1, c(1, n.delta)],
  age.mean$never_taker$est[1, c(1, n.delta)], age.mean$never_taker$sd[1, c(1, n.delta)]),
  sep = "")
cat(sprintf("Panel B (mean age): always-takers %.1f (SE %.2f)\n",
            at_mean, age.mean$always_taker$sd))

median_age <- function(label) {
  d <- df_cdf[df_cdf$stratum == label, ]
  d$age[which(d$pe >= 0.5)[1]]
}
cat(sprintf(
  "Panel C (age CDF at delta = %.2f, delta.seq[%d] of %d): median age -- compliers %s, never-takers %s, always-takers %s\n",
  delta_val, delta_idx, n.delta, median_age("Compliers"),
  median_age("Never-Takers"), median_age("Always-Takers")))
