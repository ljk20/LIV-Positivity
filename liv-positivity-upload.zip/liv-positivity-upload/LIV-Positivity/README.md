# Replication archive: *Local Effects of Continuous Instruments without Positivity*

Reproduces the empirical analysis and simulation study in:

> Rakshit, P., Levis, A. W., and Keele, L. (2026). Local Effects of Continuous
> Instruments without Positivity. *Journal of the Royal Statistical Society,
> Series B*.

The analysis data are restricted, so every script here defaults to the
synthetic example dataset in `data/` (see `data/README.md`). The pipeline then
runs end to end and produces output of the right shape, but **the numbers it
produces are not the paper's numbers**. To reproduce those, point
`LIV_DATA_FILE` at the real file.


## Quickstart

```bash
git clone https://github.com/ljk20/LIV-Positivity.git
cd LIV-Positivity
R -e 'install.packages("renv"); renv::restore()'
Rscript run_all.R
```

`renv::restore()` installs the package versions pinned in `renv.lock`. To skip
renv, install the packages in the dependency table below and run `run_all.R`
directly.

On the synthetic data the application takes a couple of minutes. **The
simulation takes days** — 1,000 replications at each of six sample sizes up to
15,000 — so run it deliberately rather than as part of a first look.


## What gets reproduced

| Manuscript element | Script(s) | Output |
|---|---|---|
| Figure 4 (positivity diagnostics: minimum conditional density, hospital TTO ranges, uncovered TTO stretches) | `application/01_density-estimation.R`, `04_figure-4.R` | `figures/application/tto_positivity.pdf` (and `tto_positivity_gaps.pdf`, a density-vs-direct comparison used in the response, not in the paper) |
| Figure 5 (δ-tilted LATE by δ and by mean TTO) | `application/02_estimation.R`, `05_figure-5.R` | `tto-est-1.pdf`, `tto-est-2.pdf` |
| Figure 6 (sepsis prevalence by principal stratum) | `application/03_estimation-supp.R`, `06_figure-S6.R` | `sepsis-profile.pdf` |
| Figure 7 (mean age by stratum; age distribution function) | `application/03_estimation-supp.R`, `06_figure-S6.R` | `age-profile-1.pdf`, `age-profile-2.pdf` |
| Figure 8 (monotonicity sensitivity surfaces) | `application/03_estimation-supp.R`, `07_figure-S7.R` | `mono-sens-low-delta.pdf`, `mono-sens-high-delta.pdf` |
| Figures 1–3 (simulation: bias, SE, SE calibration, coverage) | `simulation/01_sim-parallel.R`, `02_sim-figures.R` | `figures/simulation/sim1-fig{1,2,3,4}*.pdf` |
| Section 7 numbers (complier share, ψ̂(0), mean TTO, stratum profiles, sensitivity grids) | the scripts above | printed to stdout as each runs |
| Sensitivity of ψ̂ at the largest tilt to individual patients | `application/08_delta-sensitivity.R` | `output/application/delta-sensitivity.RData`, printed table |

Run the scripts in their numbered order: `02` writes the cross-fitted pieces
that `03` and `08` read.


## Repository layout

```
liv-positivity-replication/
├── R/                          shared estimator code
│   ├── late-funcs-fast.R       late_fast(), late_delta_0_fast(), iv_mean_fast()
│   ├── profile-funcs.R         principal-stratum profiles
│   ├── sensitivity_xi.R        monotonicity sensitivity
│   └── funcs-sim.R             simulation DGP and true values
├── application/                cholecystitis / TTO scripts (numbered 01-08)
├── simulation/                 Monte Carlo scripts (numbered 01-02)
├── data/                       synthetic example data + its generator
├── output/                     intermediate .RData (created at runtime)
├── figures/                    final PDFs (created at runtime)
├── run_all.R                   master driver
├── README.md                   this file
├── LICENSE                     MIT
├── CITATION.cff                how to cite
├── .Rprofile                   activates renv when present
└── renv.lock                   pinned R package versions
```


## Dependencies

R ≥ 4.3 (the saved runs used 4.5.2) with these CRAN packages:

| Package | Used in |
|---|---|
| `tidyverse`, `dplyr` | application, simulation |
| `here` | all scripts (paths are resolved from the archive root) |
| `foreign` | application (Stata file I/O) |
| `fixest` | application (hospital fixed-effect residualization) |
| `np` | application (conditional density estimation) |
| `ranger`, `gam`, `nnls` | learners inside the SuperLearner ensemble |
| `SuperLearner` | application, simulation (nuisance estimation) |
| `mvtnorm`, `statmod` | application, simulation |
| `parallel` | application, simulation |
| `furrr`, `future` | simulation (parallel replications) |
| `ggplot2`, `patchwork`, `scales` | figure scripts |

`gam` matters: SuperLearner drops a learner whose package is missing with only
a warning, so without it the ensemble silently differs from the paper's.
`02_estimation.R` stops at the outset if it is not installed.

`renv.lock` pins the versions used here, listing each package's installed
version with CRAN as the source. Running `renv::init(bare = TRUE)` followed by
`renv::snapshot()` inside the archive will regenerate it from your own library.


## Data

The analysis file is restricted and cannot be redistributed; see
`data/README.md` for the schema, how to obtain it, and how the synthetic
stand-in is built. Set `LIV_DATA_FILE` to run any script on the real file.

`02_estimation.R` also writes per-patient pieces of the fit, which `03` and
`08` reuse instead of refitting. With restricted data, set `LIV_PIECES_FILE`
to a location your data agreement allows.


## Re-running individual pieces

```bash
# Application only (02 must run before 03 and 08)
Rscript application/02_estimation.R
Rscript application/03_estimation-supp.R
Rscript application/05_figure-5.R
Rscript application/06_figure-S6.R
Rscript application/07_figure-S7.R

# Positivity figure (01 is the slow part)
Rscript application/01_density-estimation.R
Rscript application/04_figure-4.R

# Simulation (days; see the warning above)
Rscript simulation/01_sim-parallel.R
Rscript simulation/02_sim-figures.R
```
