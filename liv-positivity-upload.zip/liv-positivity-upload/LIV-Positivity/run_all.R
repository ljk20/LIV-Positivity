# =============================================================================
# run_all.R — master replication driver.
#
# Runs the full pipeline in order: application (Density-Estimation +
# Estimation + Estimation-Supp + figures), then simulation (driver + figures).
#
# Default behaviour: reads the included synthetic data file
# data/iv_match_synthetic.dta.  To run on the restricted real data, set
# LIV_DATA_FILE in your environment before starting R, or call
#   Sys.setenv(LIV_DATA_FILE = "/path/to/real/iv_match.dta")
# at the R prompt before sourcing this script.
#
# Runtime (on the real data, ~6 cores): about 4 h for 02_estimation.R, under
# an hour for 03_estimation-supp.R, minutes for everything else in the
# application; the simulation takes days (1,000 replications at each of six
# sample sizes up to 15,000).  On the included synthetic data the whole
# application runs in a couple of minutes.
#
# This is intentionally a sequential master driver.  Each script writes
# its outputs to disk, so any single step can be re-run in isolation.
# =============================================================================

library(here)

# Activate renv if available (no-op if renv is not initialized yet)
if (file.exists(here("renv/activate.R"))) {
  source(here("renv/activate.R"))
  if (requireNamespace("renv", quietly = TRUE)) {
    renv::restore(prompt = FALSE)
  }
}

# Application -----------------------------------------------------------------
source(here("application/01_density-estimation.R"))
source(here("application/02_estimation.R"))
source(here("application/03_estimation-supp.R"))
source(here("application/04_figure-4.R"))
source(here("application/05_figure-5.R"))
source(here("application/06_figure-S6.R"))
source(here("application/07_figure-S7.R"))
source(here("application/08_delta-sensitivity.R"))

# Simulation ------------------------------------------------------------------
source(here("simulation/01_sim-parallel.R"))
source(here("simulation/02_sim-figures.R"))

cat("\nAll pipelines complete.  Outputs in output/, figures in figures/.\n")
