# Data

The cholecystitis application data used in Rakshit, Levis, and Keele (2026)
are **restricted** and cannot be redistributed. The pipeline reads a single
Stata file via `foreign::read.dta()`; each script resolves the path through
the `LIV_DATA_FILE` environment variable.

## Reproducing on the real data

1. Obtain a copy of the merged file from the original data sources (see below).
2. Place it anywhere on disk (e.g., `/path/to/iv_match.dta`).
3. Before launching R, set the environment variable:

   ```bash
   export LIV_DATA_FILE=/path/to/iv_match.dta
   ```

   Or from R:

   ```r
   Sys.setenv(LIV_DATA_FILE = "/path/to/iv_match.dta")
   ```

4. Run `source("run_all.R")` (or any individual script under `application/`).

If `LIV_DATA_FILE` is unset, the application scripts default to
`data/iv_match_synthetic.dta` (see "Synthetic example" below).

## Data sources

The analytic file is a merge of four restricted data products covering
calendar years 2012–2013:

| Source | Provider | Purpose |
|---|---|---|
| Physician Masterfile | American Medical Association (AMA) Physician Professional Data | Surgeon identifiers, specialty, and surgeon-level tendency-to-operate (TTO) used as the IV. |
| New York SPARCS | New York State Department of Health, Statewide Planning and Research Cooperative System | Inpatient discharge claims for NY hospitals. |
| Florida AHCA | Florida Agency for Health Care Administration | Inpatient discharge claims for FL hospitals. |
| Pennsylvania PHC4 | Pennsylvania Health Cost Containment Council | Inpatient discharge claims for PA hospitals. |

Each provider has its own data-use agreement (DUA), application process, and
fee schedule. The merge to a single patient-surgeon-episode file was done
in advance of the analysis; the pipeline here consumes that pre-merged file
only.

The merged file contains one row per patient episode (n ≈ 123,000 after
restricting to cholecystitis, `shafi17 == 1`). Per the data-use agreement,
each patient appears in the file at most once.

## Expected column schema

The scripts under `application/` expect the following columns. Types are
those produced by `read.dta()` on the merged Stata file.

| Column | Type | Description |
|---|---|---|
| `shafi17` | numeric (0/1) | Cholecystitis indicator (the analytic cohort) |
| `died` | numeric (0/1) | In-hospital death |
| `prolonged` | numeric (0/1) | Prolonged length of stay |
| `hospid` | character/numeric | Hospital identifier (for hospital fixed effects) |
| `surg` | numeric (0/1) | Treatment: 1 = operative care, 0 = non-operative |
| `pref` | numeric in [0, 1] | Instrument: surgeon's tendency-to-operate (TTO) |
| `comorb` | numeric | Total comorbidity count |
| `angus` | numeric (0/1) | Sepsis indicator (Angus criteria) |
| `age` | numeric | Patient age in years |
| `ynel1`–`ynel31` | numeric (0/1) | 31 Elixhauser comorbidity indicators |
| `p_cat1`–`p_cat5` | numeric (0/1) | Five payer-category dummies |
| `female` | numeric (0/1) | Sex indicator |
| `hisp`, `afam`, `other` | numeric (0/1) | Race/ethnicity dummies |
| `disability_bin` | numeric (0/1) | Disability indicator |

Any analyst with a similarly-structured emergency-general-surgery dataset
can adapt the pipeline by reshaping their data to this schema.

## Synthetic example

A minimal toy dataset (`iv_match_synthetic.dta`), suitable **only** for
verifying that the pipeline executes end-to-end, is produced by
`data/make_synthetic_data.R`. It has the column schema above but with
plausible-but-fake values: every column is drawn independently from its own
marginal (so no real patient record survives), then `pref`→`surg`→outcome
relationships are imposed synthetically so the estimators are not degenerate.
No real patient information is retained, and no substantive inference should be
drawn from output computed on it.

### Generating it

`make_synthetic_data.R` reads the restricted file once, learns each column's
type and marginal distribution, and writes the fake file. Run it **with data
access available** (e.g. on the machine/VPN that can reach the restricted
file); it needs only base R + the `foreign` package, so nothing is downloaded
at run time.

```bash
# point it at the real file, then generate (writes data/iv_match_synthetic.dta)
export LIV_DATA_FILE=/path/to/iv_match.dta
Rscript data/make_synthetic_data.R
```

By default it emits only the documented columns above, at a smoke-test size of
5,000 rows. Useful overrides (all optional environment variables):

| Variable | Default | Purpose |
|---|---|---|
| `LIV_DATA_FILE` | `/Volumes/C-SHE/.../iv_match.dta` | real file to learn marginals from |
| `LIV_SYNTH_OUT` | `data/iv_match_synthetic.dta` | output path |
| `LIV_SYNTH_N` | `5000` | rows to generate (bump only if you accept the runtime) |
| `LIV_SYNTH_SEED` | `20260602` | RNG seed |

If the real file cannot be read, the script falls back to generating from the
documented schema (generic marginals) and prints a warning, so it still yields
a usable file. The generated `iv_match_synthetic.dta` is the one file under
`data/` that **is** committed to the archive (see `.gitignore`); the real
`iv_match*.dta` must never be.

Once the file exists, the pipeline picks it up automatically whenever
`LIV_DATA_FILE` is unset:

```r
Sys.unsetenv("LIV_DATA_FILE"); source("run_all.R")
```
