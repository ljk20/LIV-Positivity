# =============================================================================
# 02_sim-figures.R — Simulation figures for Section 6 of the paper.
#
# Loads each Sim-N<n>.RData written by 01_sim-parallel.R, computes diagnostics
# (integrated scaled bias and SE with jackknife Monte-Carlo SEs; per-delta SE
# calibration and pointwise asymptotic CI coverage with analytic MCSEs), and
# writes four PDFs:
#
#   sim1-fig1-scaled.pdf         Integrated sqrt(n)-scaled bias (DRML vs Plug-in)
#   sim1-fig2-scaled.pdf         Integrated sqrt(n)-scaled SE   (DRML vs Plug-in)
#   sim1-fig3-se-calibration.pdf SE calibration per-delta, 3x2 facet grid
#   sim1-fig4-coverage.pdf       Pointwise 95% CI coverage per-delta, 3x2 grid
#
# Inputs : output/simulation/Sim-N<n>.RData   (n = 500, 1000, ..., 15000)
#          output/simulation/TRUE-LATE.RData
# Outputs: figures/simulation/*.pdf
# =============================================================================

library(tidyverse)
library(patchwork)
library(here)

rm(list = ls())

output_dir  <- here("output/simulation")
figures_dir <- here("figures/simulation")
dir.create(figures_dir, recursive = TRUE, showWarnings = FALSE)

load(file.path(output_dir, "TRUE-LATE.RData"))   # true.params, delta.seq

# =============================================================================
# Discover all per-n output files
# =============================================================================
rdata_files <- sort(list.files(output_dir,
                               pattern = "^Sim-N[0-9]+\\.RData$",
                               full.names = TRUE))

if (length(rdata_files) == 0) {
  stop("No Sim-N*.RData files found in ", output_dir,
       "\nRun 01_sim-parallel.R first.")
}

cat("Found", length(rdata_files), "simulation output files:\n")
cat(paste0("  ", basename(rdata_files), "\n"), sep = "")

# =============================================================================
# Extract diagnostics from each output file
# =============================================================================
extract_diagnostics <- function(rdata_file) {
  e <- new.env()
  load(rdata_file, envir = e)

  n        <- e$n
  nsim_raw <- nrow(e$est)
  k        <- ncol(e$est)

  delta_vals <- if (exists("delta.seq", envir = e) && length(e$delta.seq) == k) {
    e$delta.seq
  } else {
    delta.seq
  }

  # Drop rows with any NA (failed reps).
  keep     <- complete.cases(e$est, e$est.plug, e$sd)
  n_kept   <- sum(keep)
  n_failed <- nsim_raw - n_kept

  if (n_failed > 0) {
    cat(sprintf("  %s: %d / %d reps failed -- excluded from diagnostics\n",
                basename(rdata_file), n_failed, nsim_raw))
  }

  est_mat      <- e$est[keep, , drop = FALSE]
  est_plug_mat <- e$est.plug[keep, , drop = FALSE]
  sd_mat       <- e$sd[keep, , drop = FALSE]

  se_if_delta <- colMeans(sd_mat) * sqrt(n)

  cvg <- numeric(k)
  for (j in seq_len(k)) {
    lcl    <- est_mat[, j] - 1.96 * sd_mat[, j]
    ucl    <- est_mat[, j] + 1.96 * sd_mat[, j]
    cvg[j] <- mean((lcl < true.params[j]) & (true.params[j] < ucl))
  }
  mcse_cvg <- sqrt(cvg * (1 - cvg) / n_kept)

  list(
    n            = n,
    n_label      = format(n, big.mark = ","),
    delta.seq    = delta_vals,
    nsim_raw     = nsim_raw,
    nsim         = n_kept,
    n_failed     = n_failed,
    bi  = mean(abs(colMeans(est_mat)      - true.params)) * sqrt(n),
    bp  = mean(abs(colMeans(est_plug_mat) - true.params)) * sqrt(n),
    sei = mean(apply(est_mat,      2, sd)) * sqrt(n),
    sep = mean(apply(est_plug_mat, 2, sd)) * sqrt(n),
    se_if_delta  = se_if_delta,
    se_emp_delta = apply(est_mat, 2, sd) * sqrt(n),
    cvg          = cvg,
    mcse_cvg     = mcse_cvg,
    est_mat      = est_mat,
    est_plug_mat = est_plug_mat,
    sd_mat       = sd_mat
  )
}

diags    <- map(rdata_files, extract_diagnostics)
diags    <- diags[order(map_dbl(diags, "n"))]
n_labels <- map_chr(diags, "n_label")

cat("\nProcessed sample sizes:\n")
for (d in diags) {
  cat(sprintf("  n = %-6d   nsim = %d / %d (%d failed)\n",
              d$n, d$nsim, d$nsim_raw, d$n_failed))
}
if (any(map_dbl(diags, "n_failed") > 0)) {
  cat("NOTE: failed replications were excluded before diagnostics.\n")
}

# =============================================================================
# Monte Carlo Standard Errors (Morris et al. 2019, Table II)
# Jackknife for integrated quantities; analytic for per-delta quantities.
# =============================================================================
jackknife_mcse_bias <- function(est_mat, true_params, n) {
  nsim <- nrow(est_mat)
  full_means <- colMeans(est_mat)
  jack_vals <- vapply(seq_len(nsim), function(i) {
    means_loo <- (nsim * full_means - est_mat[i, ]) / (nsim - 1)
    mean(abs(means_loo - true_params)) * sqrt(n)
  }, numeric(1))
  sqrt((nsim - 1) / nsim * sum((jack_vals - mean(jack_vals))^2))
}

jackknife_mcse_empse <- function(est_mat, n) {
  nsim <- nrow(est_mat)
  col_sum  <- colSums(est_mat)
  col_sum2 <- colSums(est_mat^2)
  jack_vals <- vapply(seq_len(nsim), function(i) {
    s  <- col_sum  - est_mat[i, ]
    s2 <- col_sum2 - est_mat[i, ]^2
    m  <- nsim - 1
    loo_var <- (s2 - s^2 / m) / (m - 1)
    mean(sqrt(pmax(loo_var, 0))) * sqrt(n)
  }, numeric(1))
  sqrt((nsim - 1) / nsim * sum((jack_vals - mean(jack_vals))^2))
}

for (idx in seq_along(diags)) {
  d <- diags[[idx]]
  diags[[idx]]$mcse_bi  <- jackknife_mcse_bias(d$est_mat,      true.params, d$n)
  diags[[idx]]$mcse_bp  <- jackknife_mcse_bias(d$est_plug_mat, true.params, d$n)
  diags[[idx]]$mcse_sei <- jackknife_mcse_empse(d$est_mat,      d$n)
  diags[[idx]]$mcse_sep <- jackknife_mcse_empse(d$est_plug_mat, d$n)
  nsim_mc <- d$nsim
  diags[[idx]]$mcse_se_if_delta  <- apply(d$sd_mat * sqrt(d$n), 2, sd) / sqrt(nsim_mc)
  diags[[idx]]$mcse_se_emp_delta <- d$se_emp_delta / sqrt(2 * (nsim_mc - 1))
}

cat("Monte Carlo SEs computed (jackknife for integrated, analytic for per-delta)\n")

# =============================================================================
# Tidy summary data frames
# =============================================================================
bias_data <- tibble(
  n_label = rep(n_labels, each = 2),
  method  = rep(c("DRML", "Plug-in"), times = length(diags)),
  value   = flatten_dbl(map(diags, ~ c(.x$bi, .x$bp))),
  mcse    = flatten_dbl(map(diags, ~ c(.x$mcse_bi, .x$mcse_bp)))
) |>
  mutate(n_label = factor(n_label, levels = n_labels))

se_data <- tibble(
  n_label = rep(n_labels, each = 2),
  method  = rep(c("DRML", "Plug-in"), times = length(diags)),
  value   = flatten_dbl(map(diags, ~ c(.x$sei, .x$sep))),
  mcse    = flatten_dbl(map(diags, ~ c(.x$mcse_sei, .x$mcse_sep)))
) |>
  mutate(n_label = factor(n_label, levels = n_labels))

calib_data <- map_dfr(diags, function(d) {
  k <- length(d$se_if_delta)
  tibble(
    n_label = d$n_label,
    delta   = rep(d$delta.seq, 2),
    sd_val  = c(d$se_if_delta, d$se_emp_delta),
    mcse    = c(d$mcse_se_if_delta, d$mcse_se_emp_delta),
    source  = c(rep("Estimated (IF)", k), rep("Empirical", k))
  )
}) |>
  mutate(n_label = factor(n_label, levels = n_labels))

cvg_data <- map_dfr(diags, function(d) {
  tibble(
    n_label = d$n_label,
    delta   = d$delta.seq,
    cvg     = d$cvg,
    mcse    = d$mcse_cvg
  )
}) |>
  mutate(n_label = factor(n_label, levels = n_labels))

# =============================================================================
# Figures
# =============================================================================
bar_theme <- list(
  scale_fill_manual(values = c("DRML" = "grey60", "Plug-in" = "lightblue")),
  theme_minimal(base_size = 11),
  theme(axis.text.x = element_text(angle = 30, hjust = 1))
)

# Figure 1: Integrated scaled bias
p1 <- ggplot(bias_data, aes(x = n_label, y = value, fill = method)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_errorbar(aes(ymin = value - 1.96 * mcse, ymax = value + 1.96 * mcse),
                position = position_dodge(width = 0.9), width = 0.25) +
  labs(x = "Sample Size",
       y = expression(paste("Integrated ", sqrt(n), "-Scaled Bias")),
       fill = "Method",
       caption = "Error bars: 95% Monte Carlo CI") +
  bar_theme +
  theme(plot.caption = element_text(hjust = 0.5))

# Figure 2: Integrated scaled SE
p2 <- ggplot(se_data, aes(x = n_label, y = value, fill = method)) +
  geom_bar(stat = "identity", position = "dodge") +
  geom_errorbar(aes(ymin = value - 1.96 * mcse, ymax = value + 1.96 * mcse),
                position = position_dodge(width = 0.9), width = 0.25) +
  labs(x = "Sample Size",
       y = expression(paste("Integrated ", sqrt(n), "-Scaled SE")),
       fill = "Method",
       caption = "Error bars: 95% Monte Carlo CI") +
  bar_theme +
  theme(plot.caption = element_text(hjust = 0.5))

# Figure 3: SE calibration (3 x 2 panel grid via patchwork)
fig3_width <- 3.0 * 3 + 0.5
panel_levels <- unique(calib_data$n_label)

make_panel <- function(dat, panel_title) {
  ggplot(dat, aes(x = delta, y = sd_val, color = source, linetype = source)) +
    geom_ribbon(aes(ymin = sd_val - 1.96 * mcse, ymax = sd_val + 1.96 * mcse,
                    fill = source), alpha = 0.15, linetype = 0) +
    geom_line(linewidth = 0.8) +
    geom_point(size = 1.5) +
    labs(x        = expression(paste("Shift parameter ", delta)),
         y        = expression(sqrt(n) %*% SD),
         title    = panel_title,
         color    = NULL, linetype = NULL, fill = NULL) +
    scale_color_manual(values = c("Estimated (IF)" = "black",
                                  "Empirical"      = "steelblue")) +
    scale_fill_manual(values = c("Estimated (IF)" = "grey50",
                                 "Empirical"      = "steelblue"),
                      guide  = "none") +
    scale_linetype_manual(values = c("Estimated (IF)" = "solid",
                                     "Empirical"      = "dashed")) +
    theme_bw(base_size = 11) +
    theme(legend.position  = "bottom",
          strip.background = element_blank(),
          strip.text       = element_text(face = "bold"),
          plot.title       = element_text(hjust = 0.5, face = "bold"))
}

panels <- lapply(panel_levels, function(lev) {
  make_panel(calib_data[calib_data$n_label == lev, ], lev)
})

row1 <- panels[[1]] + panels[[2]] + panels[[3]]
row2 <- panels[[4]] + panels[[5]] + panels[[6]]

p3 <- (row1 / row2) +
  plot_layout(guides = "collect") +
  plot_annotation(
    caption = "Shaded bands: 95% Monte Carlo CI",
    theme   = theme(plot.caption    = element_text(hjust = 0.5),
                    legend.position = "bottom")
  )

# Figure 4: pointwise coverage (3 x 2 facet grid)
cvg_n_col  <- 3L
cvg_n_row  <- 2L
cvg_width  <- 3.0 * cvg_n_col + 0.5
cvg_height <- 3.5 * cvg_n_row

p4 <- ggplot(cvg_data, aes(x = delta, y = cvg)) +
  geom_ribbon(aes(ymin = cvg - 1.96 * mcse, ymax = cvg + 1.96 * mcse),
              alpha = 0.2) +
  geom_line(linewidth = 0.8) +
  geom_point(size = 1.5) +
  geom_hline(yintercept = 0.95, linetype = "dashed", color = "grey40") +
  facet_wrap(~ n_label, nrow = cvg_n_row, ncol = cvg_n_col) +
  labs(x       = expression(paste("Shift parameter ", delta)),
       y       = "Coverage Probability",
       caption = "Shaded bands: 95% Monte Carlo CI") +
  coord_cartesian(ylim = c(0.85, 1)) +
  theme_bw(base_size = 11) +
  theme(strip.background = element_blank(),
        strip.text       = element_text(face = "bold"),
        plot.caption     = element_text(hjust = 0.5))

# =============================================================================
# Save figures
# =============================================================================
pdf(file.path(figures_dir, "sim1-fig1-scaled.pdf"),
    width = 4, height = 4, onefile = FALSE, paper = "special")
print(p1); dev.off()

pdf(file.path(figures_dir, "sim1-fig2-scaled.pdf"),
    width = 4, height = 4, onefile = FALSE, paper = "special")
print(p2); dev.off()

pdf(file.path(figures_dir, "sim1-fig3-se-calibration.pdf"),
    width = fig3_width, height = 6, onefile = FALSE, paper = "special")
print(p3); dev.off()

pdf(file.path(figures_dir, "sim1-fig4-coverage.pdf"),
    width = cvg_width, height = cvg_height, onefile = FALSE, paper = "special")
print(p4); dev.off()

cat("\nFigures saved to", figures_dir, "\n")
cat("  sim1-fig1-scaled.pdf          -- Integrated scaled bias\n")
cat("  sim1-fig2-scaled.pdf          -- Integrated scaled SE\n")
cat("  sim1-fig3-se-calibration.pdf  -- SE calibration: estimated vs empirical\n")
cat("  sim1-fig4-coverage.pdf        -- Pointwise asymptotic CI coverage\n")
