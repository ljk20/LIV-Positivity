# =============================================================================
# 02_estimation.R
#
# Main application estimates for the cholecystitis TTO analysis.  Runs:
#   - late_fast()        — DRML estimate of psi(delta) across the delta grid
#                          (with multiplier-bootstrap uniform CI)
#   - late_delta_0_fast()— limit point psi(0+) via the cov-form estimator
#   - iv_mean_fast()     — mean surgeon TTO under each delta-tilt
#
# Saves all three to output/application/liv-est.RData with incremental writes
# (so a crash in the second or third call does not lose the first result).
#
# Data source: by default reads data/iv_match_synthetic.dta.  To run on the
# restricted real data, set LIV_DATA_FILE before starting R (see README).
#
# Runtime: ~hours on a 6-core machine for n ~ 123k.  See CLAUDE.md history
# for the runtime caveats and known pitfalls (especially Pitfall #10 — keep
# the delta grid within the certified range).
# =============================================================================

library(tidyverse)
library(foreign)
library(fixest)
library(mvtnorm)
library(ranger)
library(parallel)
library(here)

rm(list = ls())

data_file <- Sys.getenv("LIV_DATA_FILE",
                        unset = here("data/iv_match_synthetic.dta"))
cat("Reading data from:", data_file, "\n")
data <- read.dta(data_file)

# =============================================================================
# Source estimator code
# =============================================================================
source(here("R/late-funcs-fast.R"))
source(here("R/profile-funcs.R"))
source(here("R/sensitivity_xi.R"))

# Override SL.ranger.st with a fixed, smaller num.trees (no n-adaptive scaling).
# The wrapper registrations inside late_fast / comp / nvtk / sen use an
# `exists(..., inherits = FALSE)` guard, so this .GlobalEnv definition wins.
SL.ranger.st <- function(Y, X, newX, family, obsWeights, ...) {
  SL.ranger(Y = Y, X = X, newX = newX, family = family,
            obsWeights = obsWeights, num.trees = 250L,
            num.threads = 1L, ...)
}

data.1 <- data %>% filter(shafi17 == 1)
data.1$outcome <- as.numeric(data.1$died + data.1$prolonged > 0)
nrow(data.1)
table(data.1$outcome)

setFixest_estimation(fixef.rm = "none")

feols_model <- feols(outcome ~ 1 | hospid, data = data.1)
data.1$purge <- feols_model$residuals

vars <- c("comorb", "angus", "age", "ynel1", "ynel2", "ynel3", "ynel4", "ynel5",
          "ynel6", "ynel7", "ynel8", "ynel9", "ynel10", "ynel11", "ynel12",
          "ynel13", "ynel14", "ynel15", "ynel16", "ynel17", "ynel18", "ynel19",
          "ynel20", "ynel21", "ynel22", "ynel23", "ynel24", "ynel25", "ynel26",
          "ynel27", "ynel28", "ynel29", "ynel30", "ynel31", "p_cat1", "p_cat2",
          "p_cat3", "p_cat4", "p_cat5", "female", "hisp", "afam", "other",
          "disability_bin")

y <- data.1$purge
a <- data.1$surg
z <- data.1$pref
dat <- as.data.frame(cbind(y, a, z))
x <- as.matrix(data.1[, vars])
n <- dim(dat)[1]

# Delta upper bound restricted to a range where the unpatched SL pipeline
# matches the legacy ranger-only baseline.  Raising it has historically
# produced impossible comp.eff values (> 1) at the top point.
delta.seq <- seq(.5, 4.5, length = 6)
nsplits   <- 2
ncores    <- min(6L, max(1L, parallel::detectCores() - 1L))
sl.lib    <- c("SL.ranger.st", "SL.gam", "SL.glm")

out_dir <- here("output/application")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

mod <- late_fast(
  dat       = dat,
  x         = x,
  delta.seq = delta.seq,
  nsplits   = nsplits,
  sl.lib    = sl.lib,
  ncores    = ncores,
  n_boot    = 10000L)

save(mod, n, file = file.path(out_dir, "liv-est.RData"))

mod.0 <- late_delta_0_fast(
  dat       = dat,
  x         = x,
  nsplits   = nsplits,
  sl.lib    = sl.lib)

save(mod, mod.0, n, file = file.path(out_dir, "liv-est.RData"))

mod.mean <- iv_mean_fast(
  dat       = dat,
  x         = x,
  delta.seq = delta.seq,
  nsplits   = nsplits,
  sl.lib    = sl.lib,
  ncores    = ncores)

save(mod, mod.0, mod.mean, n, file = file.path(out_dir, "liv-est.RData"))

cat("\nFinal liv-est.RData saved to", out_dir, "\n")
