# =============================================================================
# 06_figure-S6.R — Figure S6: principal-stratum profile diagnostics.
#
# Panel A (sepsis-profile.pdf):    Pr(Sepsis = 1) for compliers vs. never-takers
#                                  across delta.
# Panel B (age-profile-1.pdf):     density of age at the median age slice for
#                                  compliers vs. never-takers across delta.
# Panel C (age-profile-2.pdf):     density of age across the age grid at the
#                                  median delta in the grid.
#
# Error bars are pointwise 95% normal CIs (est +/- 1.96 * sd), NOT the uniform
# multiplier-bootstrap bands used in Figure 5.
#
# Inputs : output/application/sepsis-profile.RData
#          output/application/age-profile.RData
# Outputs: figures/application/sepsis-profile.pdf
#          figures/application/age-profile-1.pdf
#          figures/application/age-profile-2.pdf
# =============================================================================

library(ggplot2)
library(here)

rm(list = ls())

# Must match the delta.seq used in 03_estimation-supp.R.
delta.seq <- seq(.5, 4.5, length = 6)
n.delta   <- length(delta.seq)

pad_ylim <- function(lower, upper) {
  r <- range(c(lower, upper))
  r + c(-1, 1) * 0.05 * diff(r)
}

fig_dir <- here("figures/application")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)

# Panel A: Pr(Sepsis = 1) for compliers vs. never-takers across delta --------
load(here("output/application/sepsis-profile.RData"))

df_sepsis <- data.frame(
  delta    = c(delta.seq, delta.seq),
  pe       = c(comp.out$est.eff, nt.out$est.eff),
  lcl      = c(comp.out$est.eff - 1.96 * comp.out$sd,
               nt.out$est.eff   - 1.96 * nt.out$sd),
  ucl      = c(comp.out$est.eff + 1.96 * comp.out$sd,
               nt.out$est.eff   + 1.96 * nt.out$sd),
  contrast = factor(rep(c(1, 2), each = n.delta),
                    levels = c(1, 2),
                    labels = c("Compliers", "Never-Takers"))
)

ylim_sepsis <- pad_ylim(df_sepsis$lcl, df_sepsis$ucl)

p1 <- ggplot(df_sepsis, aes(delta, shape = contrast)) +
  geom_point(aes(y = pe), size = 3) +
  geom_errorbar(aes(ymin = lcl, ymax = ucl), width = 0.2, linewidth = 0.6) +
  coord_cartesian(ylim = ylim_sepsis) +
  scale_y_continuous(labels = scales::label_percent(accuracy = 0.1)) +
  scale_shape_manual(name = "Principal Stratum", values = c(4, 5)) +
  xlab(expression(delta)) +
  ylab("Pr(Sepsis = 1)") +
  theme_bw(base_size = 18) +
  theme(legend.position = "top")

ggsave(file.path(fig_dir, "sepsis-profile.pdf"), p1, width = 8, height = 6)

# Panel B: density of age at the median age slice across delta ---------------
load(here("output/application/age-profile.RData"))

med_age_idx <- ceiling(length(seq1) / 2)
med_age_val <- seq1[med_age_idx]

df_age_delta <- data.frame(
  delta    = c(delta.seq, delta.seq),
  pe       = c(comp.est[med_age_idx, ], nt.est[med_age_idx, ]),
  lcl      = c(comp.est[med_age_idx, ] - 1.96 * comp.sd[med_age_idx, ],
               nt.est[med_age_idx, ]   - 1.96 * nt.sd[med_age_idx, ]),
  ucl      = c(comp.est[med_age_idx, ] + 1.96 * comp.sd[med_age_idx, ],
               nt.est[med_age_idx, ]   + 1.96 * nt.sd[med_age_idx, ]),
  contrast = factor(rep(c(1, 2), each = n.delta),
                    levels = c(1, 2),
                    labels = c("Compliers", "Never-Takers"))
)

ylim_age_delta <- pad_ylim(df_age_delta$lcl, df_age_delta$ucl)

p2 <- ggplot(df_age_delta, aes(delta, shape = contrast)) +
  geom_point(aes(y = pe), size = 3) +
  geom_errorbar(aes(ymin = lcl, ymax = ucl), width = 0.2, linewidth = 0.6) +
  coord_cartesian(ylim = ylim_age_delta) +
  scale_shape_manual(name = "Principal Stratum", values = c(4, 5)) +
  xlab(expression(delta)) +
  ylab("Estimated Density of Age") +
  theme_bw(base_size = 18) +
  theme(legend.position = "top")

ggsave(file.path(fig_dir, "age-profile-1.pdf"), p2, width = 8, height = 6)

# Panel C: density of age across the age grid at the median delta ------------
delta_idx <- ceiling(length(delta.seq) / 2)
delta_val <- delta.seq[delta_idx]
n.age     <- length(seq1)

df_age_grid <- data.frame(
  age      = c(seq1, seq1),
  pe       = c(comp.est[, delta_idx], nt.est[, delta_idx]),
  lcl      = c(comp.est[, delta_idx] - 1.96 * comp.sd[, delta_idx],
               nt.est[, delta_idx]   - 1.96 * nt.sd[, delta_idx]),
  ucl      = c(comp.est[, delta_idx] + 1.96 * comp.sd[, delta_idx],
               nt.est[, delta_idx]   + 1.96 * nt.sd[, delta_idx]),
  contrast = factor(rep(c(1, 2), each = n.age),
                    levels = c(1, 2),
                    labels = c("Compliers", "Never-Takers"))
)

ylim_age_grid <- pad_ylim(df_age_grid$lcl, df_age_grid$ucl)

p3 <- ggplot(df_age_grid, aes(age, shape = contrast)) +
  geom_point(aes(y = pe), size = 3) +
  geom_line(aes(y = pe, linetype = contrast), linewidth = 0.6) +
  geom_errorbar(aes(ymin = lcl, ymax = ucl), width = 0.5, linewidth = 0.6) +
  coord_cartesian(ylim = ylim_age_grid) +
  scale_shape_manual(name = "Principal Stratum", values = c(4, 5)) +
  scale_linetype_manual(name = "Principal Stratum",
                        values = c("solid", "dashed")) +
  xlab("Age (years)") +
  ylab("Estimated Density of Age") +
  theme_bw(base_size = 18) +
  theme(legend.position = "top")

ggsave(file.path(fig_dir, "age-profile-2.pdf"), p3, width = 8, height = 6)

# Summary printouts for the paper text ---------------------------------------
cat(sprintf(
  "Panel A (sepsis): Pr(Sepsis = 1) at delta = %.2f -- compliers %.2f%%, never-takers %.2f%%\n",
  delta.seq[1], 100 * comp.out$est.eff[1], 100 * nt.out$est.eff[1]))
cat(sprintf(
  "Panel A (sepsis): Pr(Sepsis = 1) at delta = %.2f -- compliers %.2f%%, never-takers %.2f%%\n",
  delta.seq[n.delta], 100 * comp.out$est.eff[n.delta], 100 * nt.out$est.eff[n.delta]))

cat(sprintf(
  "Panel B (age density): median age slice = %.1f years (seq1[%d] of %d)\n",
  med_age_val, med_age_idx, length(seq1)))

cat(sprintf(
  "Panel C (age density): plotted at delta = %.2f (delta.seq[%d] of %d)\n",
  delta_val, delta_idx, n.delta))
