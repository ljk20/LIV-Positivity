# =============================================================================
# 07_figure-S7.R — Figure S7: monotonicity sensitivity heatmaps.
#
# Panel A (mono-sens-low-delta.pdf):  sensitivity surface at delta_tilt = 0.5.
# Panel B (mono-sens-high-delta.pdf): sensitivity surface at delta_tilt = 4.5.
#
# Inputs : output/application/Mono-Sens-Delta-0.50.RData (df_tilt_low or legacy plot.data.d1)
#          output/application/Mono-Sens-Delta-4.50.RData (df_tilt_high or legacy plot.data.d2)
# Outputs: figures/application/mono-sens-low-delta.pdf
#          figures/application/mono-sens-high-delta.pdf
#
# The loader is agnostic to the saved object name (legacy plot.data.d{1,2}
# vs. current df_tilt_{low,high}).  Color fill is Spectral with direction = -1;
# limits are robust 2nd / 98th percentiles with oob = scales::squish.  Dashed
# contour at level = 0 marks the sign-flip threshold.
# =============================================================================

library(ggplot2)
library(here)

rm(list = ls())

# Loads a Mono-Sens .RData file regardless of the saved object's name.
load_mono_sens <- function(path) {
  e <- new.env(parent = emptyenv())
  ns <- load(path, envir = e)
  if (length(ns) != 1L) {
    stop("expected exactly one object in ", path,
         "; found: ", paste(ns, collapse = ", "))
  }
  df <- get(ns[1], envir = e)
  data.frame(
    p_defier = df$delta,
    eff_diff = df$eps,
    level    = df$level
  )
}

plot_mono_sens <- function(df) {
  lims <- quantile(df$level, c(0.02, 0.98), na.rm = TRUE)
  ggplot(df, aes(p_defier, eff_diff)) +
    geom_raster(aes(fill = level)) +
    scale_fill_distiller(palette   = "Spectral",
                         direction = -1,
                         limits    = lims,
                         oob       = scales::squish) +
    geom_contour(aes(z = level),
                 breaks   = 0,
                 colour   = "black",
                 linetype = "dashed") +
    labs(x    = "P(Defier)",
         y    = "Average Effect Difference\nBetween Compliers and Defiers",
         fill = "LATE Upper Bound") +
    theme_minimal(base_size = 18) +
    theme(legend.position  = "bottom",
          legend.key.width = unit(2, "cm"))
}

summarize_mono_sens <- function(df, label) {
  cat(sprintf("---- %s ----\n", label))
  cat(sprintf("  level range: [%.4f, %.4f]\n",
              min(df$level, na.rm = TRUE),
              max(df$level, na.rm = TRUE)))
  cat(sprintf("  fraction of cells with sign flip (level >= 0): %.1f%%\n",
              100 * mean(df$level >= 0, na.rm = TRUE)))
  flip <- subset(df, level >= 0)
  if (nrow(flip) == 0) {
    cat("  no sign flip within the displayed grid\n")
  } else {
    flip$l1 <- flip$p_defier + flip$eff_diff
    nearest <- flip[which.min(flip$l1), ]
    cat(sprintf(
      "  nearest-origin sign flip: P(Defier) = %.3f, eff_diff = %.3f, level = %.4f\n",
      nearest$p_defier, nearest$eff_diff, nearest$level))
  }
  zero_eff <- subset(df, eff_diff == 0 & level < 0)
  if (nrow(zero_eff) > 0) {
    cat(sprintf(
      "  max P(Defier) with level < 0 at eff_diff = 0: %.3f\n",
      max(zero_eff$p_defier)))
  }
  zero_pd <- subset(df, p_defier == 0 & level < 0)
  if (nrow(zero_pd) > 0) {
    cat(sprintf(
      "  max eff_diff with level < 0 at P(Defier) = 0: %.3f\n",
      max(zero_pd$eff_diff)))
  }
}

fig_dir <- here("figures/application")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)

# Panel A: delta_tilt = 0.5 --------------------------------------------------
df_tilt_low <- load_mono_sens(
  here("output/application/Mono-Sens-Delta-0.50.RData"))

p1 <- plot_mono_sens(df_tilt_low)
ggsave(file.path(fig_dir, "mono-sens-low-delta.pdf"), p1,
       width = 7, height = 7)

# Panel B: delta_tilt = 4.5 --------------------------------------------------
df_tilt_high <- load_mono_sens(
  here("output/application/Mono-Sens-Delta-4.50.RData"))

p2 <- plot_mono_sens(df_tilt_high)
ggsave(file.path(fig_dir, "mono-sens-high-delta.pdf"), p2,
       width = 7, height = 7)

# Summary printouts ----------------------------------------------------------
summarize_mono_sens(df_tilt_low,  "Panel A (delta_tilt = 0.50)")
summarize_mono_sens(df_tilt_high, "Panel B (delta_tilt = 4.50)")
