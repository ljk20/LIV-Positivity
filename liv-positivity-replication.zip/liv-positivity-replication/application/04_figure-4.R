# =============================================================================
# 04_figure-4.R — Figure 4 (positivity-violation diagnostics).
#
# Panel left:  histogram of pi-hat(Z_i | X_i) from np::npcdens (run by
#              01_density-estimation.R).
# Panel right: histogram of minimum TTO value by hospital, from the raw data.
#
# Inputs : output/application/cdenz.RData
#          data file (default: data/iv_match_synthetic.dta; override with
#          LIV_DATA_FILE env var)
# Output : figures/application/tto_positivity.pdf
# =============================================================================

library(foreign)
library(dplyr)
library(ggplot2)
library(np)
library(gridExtra)
library(here)

rm(list = ls())

load(here("output/application/cdenz.RData"))

pi_hat <- as.numeric(fitted(cde_fit))

df_plot <- data.frame(pi_hat = pi_hat)

p1 <- ggplot(df_plot, aes(x = pi_hat)) +
  geom_histogram(bins = 50, fill = "gray85", color = "white") +
  geom_vline(xintercept = 0, linewidth = 0.5) +
  labs(x = expression(hat(pi)(Z[i] ~ "|" ~ bold(X)[i])),
       y = "Frequency") +
  theme_bw() +
  xlim(0, 0.25)

data_file <- Sys.getenv("LIV_DATA_FILE",
                        unset = here("data/iv_match_synthetic.dta"))
data <- read.dta(data_file)

df.tto <- data %>%
  group_by(hospid) %>%
  summarize(mean.pref = mean(pref),
            min.pref  = min(pref),
            max.pref  = max(pref),
            n         = n())

p2 <- ggplot(df.tto, aes(x = min.pref)) +
  geom_histogram(fill = "gray75", color = "white") +
  xlab("Minimum TTO Value by Hospital") +
  ylab("") +
  theme_minimal() +
  theme(axis.title = element_text(size = 15),
        axis.text  = element_text(size = 15))

fig_dir <- here("figures/application")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)

pdf(file.path(fig_dir, "tto_positivity.pdf"),
    width = 10, height = 4, onefile = FALSE, paper = "special")
grid.arrange(p1, p2, nrow = 1)
dev.off()

cat("Saved", file.path(fig_dir, "tto_positivity.pdf"), "\n")
