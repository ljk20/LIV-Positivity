# =============================================================================
# 03_estimation-supp.R
#
# Supplementary application analyses: principal-strata profiles (sepsis
# prevalence; age density across delta and across the age grid) and the
# monotonicity sensitivity grids at delta_tilt = 0.5 and delta_tilt = 4.5.
#
# Standalone — does not depend on liv-est.RData; refits its own nuisances.
# Duplicates the data prep from 02_estimation.R so it runs cold.
#
# Outputs (all to output/application/):
#   sepsis-profile.RData
#   age-profile.RData
#   Mono-Sens-Delta-0.50.RData
#   Mono-Sens-Delta-4.50.RData
#
# Mono-sens block is hardened against sporadic SuperLearner failures:
#   - L'Ecuyer-CMRG RNG pinned + fixed seed
#   - each sen() call wrapped in tryCatch -> NA_real_ on failure
#   - vapply enforces scalar return type so a stray try-error surfaces as NA
#   - per-block summary line prints finite-cell count and value range
# =============================================================================

library(tidyverse)
library(foreign)
library(fixest)
library(mvtnorm)
library(ranger)
library(parallel)
library(here)

rm(list = ls())

data_file <- Sys.getenv("LIV_DATA_FILE",
                        unset = here("data/iv_match_synthetic.dta"))
cat("Reading data from:", data_file, "\n")
data <- read.dta(data_file)

source(here("R/late-funcs-fast.R"))
source(here("R/profile-funcs.R"))
source(here("R/sensitivity_xi.R"))

SL.ranger.st <- function(Y, X, newX, family, obsWeights, ...) {
  SL.ranger(Y = Y, X = X, newX = newX, family = family,
            obsWeights = obsWeights, num.trees = 250L,
            num.threads = 1L, ...)
}

data.1 <- data %>% filter(shafi17 == 1)
data.1$outcome <- as.numeric(data.1$died + data.1$prolonged > 0)
nrow(data.1)
table(data.1$outcome)

setFixest_estimation(fixef.rm = "none")

feols_model <- feols(outcome ~ 1 | hospid, data = data.1)
data.1$purge <- feols_model$residuals

vars <- c("comorb", "angus", "age", "ynel1", "ynel2", "ynel3", "ynel4", "ynel5",
          "ynel6", "ynel7", "ynel8", "ynel9", "ynel10", "ynel11", "ynel12",
          "ynel13", "ynel14", "ynel15", "ynel16", "ynel17", "ynel18", "ynel19",
          "ynel20", "ynel21", "ynel22", "ynel23", "ynel24", "ynel25", "ynel26",
          "ynel27", "ynel28", "ynel29", "ynel30", "ynel31", "p_cat1", "p_cat2",
          "p_cat3", "p_cat4", "p_cat5", "female", "hisp", "afam", "other",
          "disability_bin")

y <- data.1$purge
a <- data.1$surg
z <- data.1$pref
dat <- as.data.frame(cbind(y, a, z))
x <- as.matrix(data.1[, vars])
n <- dim(dat)[1]
delta.seq <- seq(.5, 4.5, length = 6)
nsplits   <- 2
ncores    <- min(6L, max(1L, parallel::detectCores() - 1L))
sl.lib    <- c("SL.ranger.st", "SL.gam", "SL.glm")

out_dir <- here("output/application")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)


# =============================================================================
# Sepsis Profile Estimates
# =============================================================================

comp.out <- comp(dat, x, dis = TRUE, ind = 2, delta.seq = delta.seq, x0 = 1,
                 nsplits = nsplits, ncores = ncores)
at.out   <- alw(dat, x, dis = TRUE, ind = 2, x0 = 1)
nt.out   <- nvtk(dat, x, dis = TRUE, ind = 2, delta.seq = delta.seq, x0 = 1,
                 nsplits = nsplits, ncores = ncores)

comp.out.0 <- comp(dat, x, dis = TRUE, ind = 2, delta.seq = delta.seq, x0 = 0,
                   nsplits = nsplits, ncores = ncores)
at.out.0   <- alw(dat, x, dis = TRUE, ind = 2, x0 = 0)
nt.out.0   <- nvtk(dat, x, dis = TRUE, ind = 2, delta.seq = delta.seq, x0 = 0,
                   nsplits = nsplits, ncores = ncores)

save(comp.out, at.out, nt.out,
     comp.out.0, at.out.0, nt.out.0,
     file = file.path(out_dir, "sepsis-profile.RData"))


# =============================================================================
# Age Profile Estimates
# =============================================================================

seq1 <- seq(min(x[, 3]), max(x[, 3]), length.out = 7)
j    <- length(seq1)
comp.est <- matrix(NA, nrow = j, ncol = length(delta.seq))
comp.sd  <- matrix(NA, nrow = j, ncol = length(delta.seq))
nt.est   <- matrix(NA, nrow = j, ncol = length(delta.seq))
nt.sd    <- matrix(NA, nrow = j, ncol = length(delta.seq))

for (i in 1:j) {
  comp.out <- comp(dat, x, dis = FALSE, ind = 3, delta.seq = delta.seq,
                   x0 = seq1[i], nsplits = nsplits, ncores = ncores)
  nt.out   <- nvtk(dat, x, dis = FALSE, ind = 3, delta.seq = delta.seq,
                   x0 = seq1[i], nsplits = nsplits, ncores = ncores)

  comp.est[i, ] <- comp.out$est.eff
  print(comp.est[i, ])
  comp.sd[i, ]  <- comp.out$sd

  nt.est[i, ] <- nt.out$est.eff
  print(nt.est[i, ])
  nt.sd[i, ]  <- nt.out$sd
}

at.est <- matrix(NA, nrow = j, ncol = length(delta.seq))
at.sd  <- matrix(NA, nrow = j, ncol = length(delta.seq))

for (i in 1:j) {
  at.out <- alw(dat, x, dis = FALSE, ind = 3, x0 = seq1[i])
  at.est[i, ] <- at.out$est.eff
  print(at.est[i, ])
  at.sd[i, ]  <- at.out$sd
}

save(comp.est, comp.sd, nt.est, nt.sd, at.est, at.sd, seq1,
     file = file.path(out_dir, "age-profile.RData"))


# =============================================================================
# Monotonicity Sensitivity Grids
# =============================================================================
delta_tilt_low  <- delta.seq[1]
delta_tilt_high <- delta.seq[length(delta.seq)]

RNGkind("L'Ecuyer-CMRG")
set.seed(20260527)

defier.grid <- seq(0, 0.1, length.out = 10)
eps.grid    <- seq(0.0, 0.1, length.out = 10)
defier.seq  <- rep(defier.grid, length(eps.grid))
eps.seq     <- rep(eps.grid, each = length(defier.grid))
g1.g2       <- defier.seq * eps.seq
k           <- length(g1.g2)

run_sen_worker <- function(delta_tilt) {
  est_list <- parallel::mclapply(seq_len(k), function(i) {
    tryCatch({
      sen.out <- sen(dat, x, delta_tilt, g1.g2[i], nsplits = nsplits)
      sen.out$xi_hat
    }, error = function(e) NA_real_)
  }, mc.cores = ncores)
  vapply(est_list,
         function(x) if (is.numeric(x) && length(x) == 1L) x else NA_real_,
         numeric(1))
}

summarize_mono_sens_run <- function(est_vec, label) {
  n_fin <- sum(is.finite(est_vec))
  cat(sprintf("%s: %d / %d cells finite; range [%.4f, %.4f]\n",
              label, n_fin, length(est_vec),
              suppressWarnings(min(est_vec, na.rm = TRUE)),
              suppressWarnings(max(est_vec, na.rm = TRUE))))
}

# Panel A: delta_tilt = delta_tilt_low ---------------------------------------
est_d1 <- run_sen_worker(delta_tilt_low)
summarize_mono_sens_run(est_d1,
                        sprintf("mono-sens delta_tilt = %.2f", delta_tilt_low))

df_tilt_low <- data.frame(delta = defier.seq,
                          eps   = eps.seq,
                          level = est_d1)

save(df_tilt_low,
     file = file.path(out_dir,
                      sprintf("Mono-Sens-Delta-%.2f.RData", delta_tilt_low)))

# Panel B: delta_tilt = delta_tilt_high --------------------------------------
est_d2 <- run_sen_worker(delta_tilt_high)
summarize_mono_sens_run(est_d2,
                        sprintf("mono-sens delta_tilt = %.2f", delta_tilt_high))

df_tilt_high <- data.frame(delta = defier.seq,
                           eps   = eps.seq,
                           level = est_d2)

save(df_tilt_high,
     file = file.path(out_dir,
                      sprintf("Mono-Sens-Delta-%.2f.RData", delta_tilt_high)))
