# =============================================================================
# 05_figure-5.R — Figure 5: delta-tilted LATE estimates.
#
# Panel A (tto-est-1.pdf): psi-hat(delta) plotted against delta.
# Panel B (tto-est-2.pdf): same psi-hat(delta) plotted against E_delta[Z|X],
#   the mean surgeon tendency-to-operate under the delta-tilted distribution.
#
# Ribbon: 95% UNIFORM CI from the multiplier bootstrap (mod$calpha * mod$sd).
# Dashed line: limit point psi-hat(0+) from late_delta_0_fast (mod.0$est.eff).
# The normal 95% CI for psi-hat(0+) is printed to stdout at the end.
#
# Inputs : output/application/liv-est.RData (mod, mod.0, mod.mean)
# Outputs: figures/application/tto-est-1.pdf, figures/application/tto-est-2.pdf
# =============================================================================

library(ggplot2)
library(here)

rm(list = ls())

load(here("output/application/liv-est.RData"))

# Must match the delta.seq used in 02_estimation.R.
delta    <- seq(.5, 4.5, length = 6)
pe       <- mod$est.eff
ci.upper <- mod$est.eff + mod$calpha * mod$sd
ci.lower <- mod$est.eff - mod$calpha * mod$sd
tto.mean <- mod.mean$est

data.plot <- data.frame(
  delta    = delta,
  pe       = pe,
  lower    = ci.lower,
  upper    = ci.upper,
  tto.mean = tto.mean
)

ylim_r <- range(c(data.plot$lower, data.plot$upper, mod.0$est.eff))
ylim_r <- ylim_r + c(-1, 1) * 0.05 * diff(ylim_r)

# Panel A: psi-hat(delta) vs delta -------------------------------------------
p1 <- ggplot(data.plot, aes(x = delta, y = pe)) +
  geom_ribbon(aes(ymin = lower, ymax = upper), alpha = 0.1, colour = NA) +
  geom_line() +
  geom_point() +
  geom_hline(yintercept = mod.0$est.eff, linetype = "dashed") +
  annotate("text", x = max(delta), y = mod.0$est.eff,
           label = "hat(psi)(0)", parse = TRUE,
           hjust = 1, vjust = -0.5, size = 5) +
  coord_cartesian(ylim = ylim_r) +
  scale_y_continuous(labels = scales::label_percent(accuracy = 0.1)) +
  xlab(expression(delta)) +
  ylab(expression(hat(psi)(delta))) +
  theme_bw(base_size = 18)

fig_dir <- here("figures/application")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)

ggsave(file.path(fig_dir, "tto-est-1.pdf"), p1, width = 8, height = 6)

# Panel B: psi-hat(delta) vs mean surgeon tendency under delta-tilt ----------
p2 <- ggplot(data.plot, aes(x = tto.mean, y = pe)) +
  geom_ribbon(aes(ymin = lower, ymax = upper), alpha = 0.1, colour = NA) +
  geom_line() +
  geom_point() +
  geom_hline(yintercept = mod.0$est.eff, linetype = "dashed") +
  annotate("text", x = max(tto.mean), y = mod.0$est.eff,
           label = "hat(psi)(0)", parse = TRUE,
           hjust = 1, vjust = -0.5, size = 5) +
  coord_cartesian(ylim = ylim_r) +
  scale_y_continuous(labels = scales::label_percent(accuracy = 0.1)) +
  xlab(expression(paste("Mean surgeon tendency under ", delta, "-tilt"))) +
  ylab(expression(hat(psi)(delta))) +
  theme_bw(base_size = 18)

ggsave(file.path(fig_dir, "tto-est-2.pdf"), p2, width = 8, height = 6)

# Delta = 0 estimate (printout for the paper text / table) -------------------
pe.0   <- mod.0$est.eff * 100
ci.0.u <- (mod.0$est.eff + 1.96 * mod.0$sd) * 100
ci.0.l <- (mod.0$est.eff - 1.96 * mod.0$sd) * 100
cat(sprintf("psi(0+):  est = %.2f%%,  95%% normal CI [%.2f%%, %.2f%%]\n",
            pe.0, ci.0.l, ci.0.u))

# Complier fraction (percent) ------------------------------------------------
cat("Complier fraction (%) at each delta:\n")
print(round(mod$comp.eff * 100, 2))
