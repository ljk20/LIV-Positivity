# =============================================================================
# 01_density-estimation.R
#
# Estimates the conditional density pi(Z | X) via np::npcdens with a
# data-driven normal-reference bandwidth.  Output (`cdenz.RData`) is the
# input for 04_figure-4.R (the positivity-violation diagnostic).
#
# Data source: by default reads data/iv_match_synthetic.dta.  To run on the
# restricted real data, set the LIV_DATA_FILE environment variable before
# starting R, e.g.
#     Sys.setenv(LIV_DATA_FILE = "/path/to/real/iv_match.dta")
# or
#     LIV_DATA_FILE=/path/to/real/iv_match.dta Rscript application/01_...
#
# Output: output/application/cdenz.RData
# =============================================================================

library(foreign)
library(np)
library(dplyr)
library(fixest)
library(here)

rm(list = ls())

data_file <- Sys.getenv("LIV_DATA_FILE",
                        unset = here("data/iv_match_synthetic.dta"))
cat("Reading data from:", data_file, "\n")
data <- read.dta(data_file)

data.1 <- data %>% filter(shafi17 == 1)
data.1$outcome <- as.numeric(data.1$died + data.1$prolonged > 0)
nrow(data.1)
table(data.1$outcome)

setFixest_estimation(fixef.rm = "none")

feols_model <- feols(outcome ~ 1 | hospid, data = data.1)
data.1$purge <- feols_model$residuals

vars <- c("comorb", "angus", "age", "ynel1", "ynel2", "ynel3", "ynel4", "ynel5",
          "ynel6", "ynel7", "ynel8", "ynel9", "ynel10", "ynel11", "ynel12",
          "ynel13", "ynel14", "ynel15", "ynel16", "ynel17", "ynel18", "ynel19",
          "ynel20", "ynel21", "ynel22", "ynel23", "ynel24", "ynel25", "ynel26",
          "ynel27", "ynel28", "ynel29", "ynel30", "ynel31", "p_cat1", "p_cat2",
          "p_cat3", "p_cat4", "p_cat5", "female", "hisp", "afam", "other",
          "disability_bin")

y <- data.1$purge
a <- data.1$surg
z <- data.1$pref
dat <- as.data.frame(cbind(y, a, z))
x <- as.matrix(data.1[, vars])
n <- dim(dat)[1]
colnames(x) <- NULL
nos <- seq(1:ncol(x))
colnames(x) <- paste("x", nos, sep = "")

## ------------------------------------------------------------
## Conditional density estimation: pi(z | X)
## ------------------------------------------------------------
stopifnot(length(z) == nrow(x))

X <- as.data.frame(x)
names(X) <- make.names(names(X), unique = TRUE)

mhat <- as.numeric(fitted(lm(z ~ ., data = data.frame(z = z, X))))

df_full <- data.frame(z = z, mhat = mhat)
bw_1d <- npcdensbw(z ~ mhat, data = df_full, bwmethod = "normal-reference")
summary(bw_1d)

cde_fit <- npcdens(
  bws   = bw_1d,
  exdat = data.frame(mhat = df_full$mhat),
  eydat = data.frame(z    = df_full$z)
)

out_dir <- here("output/application")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
save(cde_fit, file = file.path(out_dir, "cdenz.RData"))
cat("Saved", file.path(out_dir, "cdenz.RData"), "\n")
