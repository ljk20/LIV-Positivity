# Activate renv on session startup if the lockfile has been initialized.
# A bare clone of this repo will not yet have renv/activate.R; run
#   install.packages("renv"); renv::init()
# to bootstrap, then renv::snapshot() after installing the packages listed
# in DEPENDENCIES (see top-level README).
if (file.exists("renv/activate.R")) {
  source("renv/activate.R")
}
