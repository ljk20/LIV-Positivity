
# =============================================================================
# late-funcs-fast.R
#
# SuperLearner-based nuisance estimation with performance optimizations.
# Drop-in replacements for the ranger-based functions in late-funcs.R.
#
# Key improvements over late-funcs.R:
#   (1) Nuisance functions estimated via SuperLearner ensemble rather than
#       a single ranger model
#   (2) SuperLearner internal CV uses V = 10 folds (cvControl), matching the
#       SuperLearner default.  With a 5-learner library the ensemble weights
#       are estimated more reliably at V = 10 than at V = 2; the additional
#       CV overhead is acceptable given that parallelism is handled at the
#       replication level.
#   (3) Delta loop parallelized with parallel::mclapply (set ncores > 1
#       to activate; leave at 1 when running inside a parallelized sim loop)
#   (4) Multiplier bootstrap computed via BLAS matrix multiplication
#       (crossprod) rather than column-wise sapply over n_boot iterations
#   (5) Storage pre-allocated as numeric(n) / matrix(...); the array(dim=1)
#       dynamic-growth pattern in late.delta.0 is removed
#   (6) Column names in dat normalized to lowercase so functions accept
#       data frames with y/a/z or Y/A/Z column names interchangeably
#   (7) exp(delta * Z) pre-computed once per delta call to avoid redundancy
# =============================================================================

library(SuperLearner)
library(ranger)

# =============================================================================
# Custom SuperLearner wrappers
# =============================================================================

#' Single-threaded ranger wrapper for SuperLearner with n-adaptive num.trees.
#'
#' Two design choices:
#'   (1) num.threads = 1 — parallelism is handled at the replication level
#'       (furrr::future_map), not inside ranger, to avoid thread contention.
#'   (2) num.trees scales with the training-fold size via
#'       max(500, ceiling(10 * sqrt(n_train))).  A fixed num.trees = 500 can
#'       underfit at large n because each tree sees only a bootstrap subsample
#'       of a much larger dataset; more trees reduce the forest's Monte Carlo
#'       variance without changing the bias.  Approximate values by n
#'       (with nsplits = 5, n_train ≈ 0.8 * n):
#'         n =   500 -> n_train ≈   400 -> num.trees =  500
#'         n = 1,000 -> n_train ≈   800 -> num.trees =  500
#'         n = 5,000 -> n_train ≈ 4,000 -> num.trees =  633
#'         n =10,000 -> n_train ≈ 8,000 -> num.trees =  894
#'         n =15,000 -> n_train ≈12,000 -> num.trees = 1,095
SL.ranger.st <- function(Y, X, newX, family, obsWeights, ...) {
  num.trees <- max(500L, ceiling(10L * sqrt(length(Y))))
  SL.ranger(Y = Y, X = X, newX = newX, family = family,
            obsWeights = obsWeights, num.trees = num.trees,
            num.threads = 1L, ...)
}

#' Gaussian GLM with log link for alpha_delta estimation.
#'
#' alpha_delta(X) = E[exp(delta*Z) | X].  When Z | X is Normal with a linear
#' conditional mean, log(alpha_delta) is exactly linear in X, so this learner
#' is correctly specified for that nuisance target.  It is intentionally kept
#' out of the shared library used for gamma_Y and gamma_A, because those
#' responses can include zeros (A * exp(delta*Z) = 0 when A = 0), which cause
#' the log link to fail.
#'
#' A tryCatch fall-back to identity-link GLM guards against the rare case
#' where IRLS diverges (e.g. at extreme delta values with small folds).
SL.glm.loglink <- function(Y, X, newX, family, obsWeights, ...) {
  df <- cbind(Y = Y, as.data.frame(X))
  fit <- tryCatch(
    glm(Y ~ ., data = df, family = gaussian(link = "log"),
        weights = obsWeights,
        start   = c(log(max(mean(Y), 1e-8)), rep(0, ncol(X)))),
    error = function(e) {
      warning("SL.glm.loglink: log-link GLM failed (", conditionMessage(e),
              "); falling back to identity link.")
      glm(Y ~ ., data = df, weights = obsWeights)
    }
  )
  pred    <- pmax(predict(fit, newdata = as.data.frame(newX), type = "response"),
                 .Machine$double.eps)
  fit_obj <- list(object = fit)
  class(fit_obj) <- "SL.glm.loglink"   # required for predict dispatch
  list(pred = pred, fit = fit_obj)
}

predict.SL.glm.loglink <- function(object, newdata, ...) {
  # SuperLearner calls predict(fit_obj, newdata = ...) where fit_obj is the
  # list returned as the $fit component by SL.glm.loglink, i.e.
  # list(object = glm_fit) with class "SL.glm.loglink".
  # So `object` here IS fit_obj, and the glm object lives at object$object.
  pmax(predict(object$object, newdata = as.data.frame(newdata),
               type = "response"),
       .Machine$double.eps)
}

# =============================================================================
# late_fast: LATE sensitivity curve estimator
# =============================================================================

#' Estimate the LATE sensitivity curve over a grid of delta values.
#'
#' Semiparametric estimator using cross-fitting and influence-function-based
#' inference.  Nuisance functions (alpha, gamma_Y, gamma_A) are estimated by
#' SuperLearner on the training folds; the test-fold IF components are
#' accumulated across folds.  A multiplier bootstrap over the standardized IF
#' values yields a simultaneous 95% confidence band.
#'
#' @param dat       Data frame with columns y, a, z (case-insensitive).
#' @param x         Numeric covariate matrix (n x p).
#' @param delta.seq Numeric vector of sensitivity parameter values.
#' @param nsplits   Number of cross-fitting folds (default 2).
#' @param sl.lib    SuperLearner library; character vector of learner names.
#' @param ncores    Cores passed to parallel::mclapply for the delta loop.
#'                  Default 1 (serial); set higher when not inside a sim loop.
#' @param n_boot    Number of multiplier bootstrap draws (default 10000).
#'
#' @return Named list: est.eff, sd, calpha, comp.eff.
late_fast <- function(dat, x, delta.seq, nsplits = 2,
                      sl.lib = c("SL.ranger", "SL.mean", "SL.glm"),
                      ncores = 1L,
                      n_boot = 10000L) {

  # Register custom SL wrappers into .GlobalEnv so SuperLearner's internal
  # get() call can find them.  Referencing wrappers as symbols here (not just
  # as strings in sl.lib) forces furrr::future_map to detect and export them
  # to worker processes automatically.
  # Register custom wrappers and their S3 predict methods into .GlobalEnv.
  # furrr::future_map detects globals by scanning the worker function body for
  # named symbols; S3 methods like predict.SL.glm.loglink are not detected
  # automatically unless they are explicitly assigned here, causing
  # "no applicable method for 'predict'" in worker processes.
  .sl_wrappers <- list(SL.ranger.st           = SL.ranger.st,
                       SL.glm.loglink         = SL.glm.loglink,
                       predict.SL.glm.loglink = predict.SL.glm.loglink)
  for (nm in names(.sl_wrappers)) {
    if (!exists(nm, envir = .GlobalEnv, inherits = FALSE)) {
      assign(nm, .sl_wrappers[[nm]], envir = .GlobalEnv)
    }
  }
  rm(.sl_wrappers)

  colnames(dat) <- tolower(colnames(dat))
  n <- nrow(dat)
  k <- length(delta.seq)
  colnames(x) <- paste0("x", seq_len(ncol(x)))
  x_df <- as.data.frame(x)

  # alpha_delta(X) = E[exp(delta*Z)|X] has log(alpha_delta) linear in X when
  # Z|X is Normal with a linear conditional mean, so SL.glm.loglink is
  # correctly specified for that target.  gamma_Y and gamma_A use sl.lib
  # unchanged because their responses can be zero (A * exp(delta*Z) = 0).
  sl.lib.alpha <- unique(c(sl.lib, "SL.glm.loglink"))

  # Pre-allocate storage for IF numerator/denominator and plug-in components
  num   <- matrix(NA_real_, nrow = n, ncol = k)
  den   <- matrix(NA_real_, nrow = n, ncol = k)
  nplug <- matrix(NA_real_, nrow = n, ncol = k)  # plug-in: gamma_Y - y
  dplug <- matrix(NA_real_, nrow = n, ncol = k)  # plug-in: gamma_A - a

  # Cross-fitting fold assignments
  s <- sample(rep(seq_len(nsplits), ceiling(n / nsplits))[seq_len(n)])

  for (fold in seq_len(nsplits)) {

    train_idx <- which(s != fold)
    test_idx  <- which(s == fold)
    x_train   <- x_df[train_idx, , drop = FALSE]

    # -------------------------------------------------------------------
    # Estimate nuisance functions for every delta on this training fold.
    # The delta loop is the natural unit of parallelism: each delta value
    # requires three independent SuperLearner fits and is otherwise
    # self-contained.
    # -------------------------------------------------------------------
    fold_fits <- parallel::mclapply(seq_len(k), function(j) {

      delta  <- delta.seq[j]
      exp_dz <- exp(delta * dat$z)   # pre-compute once per delta

      # alpha: E[exp(delta * Z) | X]
      # Uses sl.lib.alpha, which appends SL.glm.loglink to the shared library.
      # SL.glm.loglink is correctly specified here (log(alpha_delta) is linear
      # in X) and will receive high ensemble weight as n grows.
      alpha_fit <- SuperLearner(
        Y          = exp_dz[train_idx],
        X          = x_train,
        SL.library = sl.lib.alpha,
        cvControl  = list(V = 10L),
        verbose    = FALSE
      )
      alpha_hat <- predict(alpha_fit, newdata = x_df)$pred

      # gamma_Y: E[Y * exp(delta * Z) | X] / alpha
      gammaY_fit <- SuperLearner(
        Y          = (dat$y * exp_dz)[train_idx],
        X          = x_train,
        SL.library = sl.lib,
        cvControl  = list(V = 10L),
        verbose    = FALSE
      )
      gamma_Y <- predict(gammaY_fit, newdata = x_df)$pred / alpha_hat

      # gamma_A: E[A * exp(delta * Z) | X] / alpha
      gammaA_fit <- SuperLearner(
        Y          = (dat$a * exp_dz)[train_idx],
        X          = x_train,
        SL.library = sl.lib,
        cvControl  = list(V = 10L),
        verbose    = FALSE
      )
      gamma_A <- predict(gammaA_fit, newdata = x_df)$pred / alpha_hat

      # Influence function components evaluated on the test fold only
      wt <- 1 - exp_dz / alpha_hat
      list(
        num   = (wt * (gamma_Y - dat$y))[test_idx],
        den   = (wt * (gamma_A - dat$a))[test_idx],
        nplug = (gamma_Y - dat$y)[test_idx],
        dplug = (gamma_A - dat$a)[test_idx]
      )

    }, mc.cores = ncores)

    # Store test-fold IF and plug-in components
    for (j in seq_len(k)) {
      num[test_idx, j]   <- fold_fits[[j]]$num
      den[test_idx, j]   <- fold_fits[[j]]$den
      nplug[test_idx, j] <- fold_fits[[j]]$nplug
      dplug[test_idx, j] <- fold_fits[[j]]$dplug
    }
  }

  # ---------------------------------------------------------------------------
  # Point estimates, influence values, and SEs
  # ---------------------------------------------------------------------------
  est.eff  <- numeric(k)
  est.plug <- numeric(k)
  comp.eff <- numeric(k)
  sd_vec   <- numeric(k)
  ifval    <- matrix(NA_real_, nrow = n, ncol = k)

  for (j in seq_len(k)) {
    mean_den    <- mean(den[, j])
    est.eff[j]  <- mean(num[, j]) / mean_den
    est.plug[j] <- mean(nplug[, j]) / mean(dplug[, j])
    comp.eff[j] <- mean_den
    ifval[, j]  <- (num[, j] - est.eff[j] * den[, j]) / mean_den
    sd_vec[j]   <- sd(ifval[, j])
  }

  # ---------------------------------------------------------------------------
  # Multiplier bootstrap for simultaneous 95% confidence band.
  #
  # Original approach: sapply over n_boot columns (n_boot loop iterations).
  # Fast approach: crossprod(mult, ifvals_std) dispatches to BLAS dgemm,
  # computing the full (n_boot x k) table of bootstrap statistics in one call.
  # For n = 5000, k = 6, n_boot = 10000 this is ~10x faster than sapply.
  # ---------------------------------------------------------------------------
  ifvals_std <- sweep(ifval, 2, sd_vec, "/")   # n x k standardized IF matrix
  mult       <- matrix(2L * rbinom(n * n_boot, 1L, 0.5) - 1L,
                       nrow = n, ncol = n_boot)
  # boot_stats: (n_boot x k), each row is one bootstrap replication
  boot_stats <- crossprod(mult, ifvals_std) / sqrt(n)
  calpha     <- quantile(apply(abs(boot_stats), 1L, max), 0.95)

  list(
    est.eff  = est.eff,
    est.plug = est.plug,
    sd       = sd_vec / sqrt(n),
    calpha   = calpha,
    comp.eff = comp.eff
  )
}


# =============================================================================
# late_delta_0_fast: standard IV/LATE estimator at delta = 0
# =============================================================================

#' Estimate the LATE at delta = 0 (standard IV/Wald estimand) via cross-fitting.
#'
#' Nuisance functions mu_z, mu_y, mu_a estimated by SuperLearner.
#' Fixes the array(dim=1) dynamic-growth pattern in the original late.delta.0().
#'
#' @param dat     Data frame with columns y, a, z (case-insensitive).
#' @param x       Numeric covariate matrix (n x p).
#' @param nsplits Number of cross-fitting folds (default 2).
#' @param sl.lib  SuperLearner library.
#'
#' @return Named list: est.eff, sd.
late_delta_0_fast <- function(dat, x, nsplits = 2,
                               sl.lib = c("SL.ranger", "SL.mean", "SL.glm")) {

  colnames(dat) <- tolower(colnames(dat))
  n <- nrow(dat)
  colnames(x) <- paste0("x", seq_len(ncol(x)))
  x_df <- as.data.frame(x)

  # Pre-allocate (replaces fragile array(dim=1) in original late.delta.0)
  num    <- numeric(n)
  den    <- numeric(n)
  den_if <- numeric(nsplits)   # fold-specific denominator scalar
  fold_n <- integer(nsplits)   # fold sizes for size-weighted average

  s <- sample(rep(seq_len(nsplits), ceiling(n / nsplits))[seq_len(n)])

  for (fold in seq_len(nsplits)) {

    train_idx <- which(s != fold)
    test_idx  <- which(s == fold)
    x_train   <- x_df[train_idx, , drop = FALSE]

    # mu_z: E[Z | X]
    zmod <- SuperLearner(Y = dat$z[train_idx], X = x_train,
                         SL.library = sl.lib, cvControl = list(V = 10L),
                         verbose = FALSE)
    mu_z <- predict(zmod, newdata = x_df)$pred

    # mu_y: E[Y | X]
    ymod <- SuperLearner(Y = dat$y[train_idx], X = x_train,
                         SL.library = sl.lib, cvControl = list(V = 10L),
                         verbose = FALSE)
    mu_y <- predict(ymod, newdata = x_df)$pred

    # mu_a: E[A | X]
    amod <- SuperLearner(Y = dat$a[train_idx], X = x_train,
                         SL.library = sl.lib, cvControl = list(V = 10L),
                         verbose = FALSE)
    mu_a <- predict(amod, newdata = x_df)$pred

    num[test_idx] <- ((dat$z - mu_z) * (dat$y - mu_y))[test_idx]
    den[test_idx] <- ((dat$z - mu_z) * (dat$a - mu_a))[test_idx]

    # Fold-specific denominator for IF normalization (matches original formula)
    den_if[fold] <- cov(dat$z[test_idx], dat$a[test_idx]) -
                    cov(mu_z[test_idx], mu_a[test_idx])
    fold_n[fold] <- length(test_idx)
  }

  # Size-weighted average of fold-specific den_if values
  mean_den_if <- sum(den_if * fold_n) / n

  est.eff <- mean(num) / mean(den)
  ifval   <- (num - est.eff * den) / mean_den_if
  se      <- sd(ifval) / sqrt(n)

  list(est.eff = est.eff, sd = se)
}


# =============================================================================
# iv_mean_fast: IV-weighted mean functional over a delta grid
# =============================================================================

#' Estimate the IV-weighted mean E[Z exp(dZ)/a + (1-exp(dZ)/a) beta_Y] over delta grid.
#'
#' @param dat       Data frame with columns y, a, z (case-insensitive).
#' @param x         Numeric covariate matrix (n x p).
#' @param delta.seq Sensitivity parameter grid.
#' @param nsplits   Number of cross-fitting folds (default 2).
#' @param sl.lib    SuperLearner library.
#' @param ncores    Cores for parallel::mclapply over delta values.
#'
#' @return Named list: est (k-vector of point estimates).
iv_mean_fast <- function(dat, x, delta.seq, nsplits = 2,
                          sl.lib = c("SL.ranger", "SL.mean", "SL.glm"),
                          ncores = 1L) {

  colnames(dat) <- tolower(colnames(dat))
  n <- nrow(dat)
  k <- length(delta.seq)
  colnames(x) <- paste0("x", seq_len(ncol(x)))
  x_df <- as.data.frame(x)

  # ifest[fold, j] stores the fold-specific estimate for delta j
  ifest <- matrix(NA_real_, nrow = nsplits, ncol = k)
  s     <- sample(rep(seq_len(nsplits), ceiling(n / nsplits))[seq_len(n)])

  for (fold in seq_len(nsplits)) {

    train_idx <- which(s != fold)
    test_idx  <- which(s == fold)
    x_train   <- x_df[train_idx, , drop = FALSE]

    fold_ests <- parallel::mclapply(seq_len(k), function(j) {

      delta  <- delta.seq[j]
      exp_dz <- exp(delta * dat$z)

      # alpha: E[exp(delta * Z) | X]
      alpha_fit <- SuperLearner(
        Y          = exp_dz[train_idx],
        X          = x_train,
        SL.library = sl.lib,
        cvControl  = list(V = 10L),
        verbose    = FALSE
      )
      alpha_hat <- predict(alpha_fit, newdata = x_df)$pred

      # beta_Y: E[Z * exp(delta * Z) | X] / alpha
      betaY_fit <- SuperLearner(
        Y          = (dat$z * exp_dz)[train_idx],
        X          = x_train,
        SL.library = sl.lib,
        cvControl  = list(V = 10L),
        verbose    = FALSE
      )
      beta_Y <- predict(betaY_fit, newdata = x_df)$pred / alpha_hat

      # Plug-in estimate on the test fold
      mean(
        dat$z[test_idx] * exp_dz[test_idx] / alpha_hat[test_idx] +
        (1 - exp_dz[test_idx] / alpha_hat[test_idx]) * beta_Y[test_idx]
      )

    }, mc.cores = ncores)

    ifest[fold, ] <- unlist(fold_ests)
  }

  list(est = colMeans(ifest))
}
