library(statmod)

simple_data <- function(n){
  yx <- rmvnorm(n, mean = rep(0,5), sigma = diag(5)/2)
  err <- yx[,1]
  x <- yx[,-1]/2
  al <- c(1,1,-1,-1)/2
  mu <- as.vector(x %*% al)   # n x 1 vector of means
  z  <- rnorm(n, mean = mu, sd = 2)
  a <- (z >= err)*1
  y <- err + 2*a
  dat <- data.frame(Y = y, A = a, Z = z, X=x)
  return(dat)
  }
  
make_data <- function(n, LATE){
          X1 <- runif(n,-1,1)
          X2 <- rbinom(n, 1, 0.3)
          U <- runif(n,-1.5,1.5)
          X <- cbind.data.frame(X1, X2)
          Z <- rnorm(n, (0.4*X[,1] - 0.8*X[,2]), 3)
          A <- rbinom(n, 1, plogis(-0.3 - 0.4*X[,1] - 0.14*X[,2] + 1.1*Z + 0.7 * U))
          r.X <- LATE - 4 * X[,1] + 6 * (X[,2] - 0.3)
          gamma.X <- 40 - 7*X[,1] - 8*X[,2]
          e.Y <- rnorm(n, sd = 2)
          Y <- r.X * A + gamma.X + 1.5 * U + e.Y
	   simDat <- data.frame(cbind(Z, Y, A, X1, X2))
	   return(simDat)
       }


true.lambda <- function(x1, x2, z) {
  grid.width <- 0.005
  us <- seq(-1.5, 1.5, by = grid.width)
  grid.width * sum(plogis(-0.3 - 0.4*x1 - 0.14*x2 + 1.1*z + 0.7 * us) / 3)
}

## Gauss-Hermite Quadrature to compute integrals
N.nodes <- 10
gh.nodes <- gauss.quad(N.nodes, kind = "hermite")$nodes
gh.weights <- gauss.quad(N.nodes, kind = "hermite")$weights

true.int.lambda <- function(x1, x2, delta) {
  herm.input <- sqrt(2) * 3 * gh.nodes + (0.4*x1 - 0.8*x2)
  h.for.quad <- sapply(1:N.nodes, function(j) {
    exp(delta * herm.input[j]) * true.lambda(x1, x2, herm.input[j])
  }, simplify = 0) / exp(delta * (0.4*x1 - 0.8*x2) + 9 * delta^2 / 2)
  sum(h.for.quad * gh.weights) / sqrt(pi)
}

true.int.mu <- function(x1, x2, delta, ATE) {
  (ATE - 4 * x1 + 6 * (x2 - 0.3)) * true.int.lambda(x1, x2, delta)
}

true.delta.late <- function(delta, ATE) {
  N <- 500000   # large MC sample so true.params has negligible Monte Carlo error
  X1 <- runif(N,-1,1)
  X2 <- rbinom(N, 1, 0.3)

  numerator <- mean(sapply(1:N, function(i) {
    true.int.mu(X1[i], X2[i], delta, ATE)
  }, simplify = 0)) -
    mean(sapply(1:N, function(i) {
      true.int.mu(X1[i], X2[i], 0, ATE)
    }, simplify = 0))
  denominator <- mean(sapply(1:N, function(i) {
    true.int.lambda(X1[i], X2[i], delta)
  }, simplify = 0)) -
    mean(sapply(1:N, function(i) {
      true.int.lambda(X1[i], X2[i], 0)
    }, simplify = 0))
  return(numerator / denominator)
}


# =============================================================================
# Deterministic computation of the true delta-tilted LATE for make_data().
#
# Replaces the Monte Carlo integration over X in true.delta.late() with
# Gauss-Legendre quadrature over X1 (continuous on [-1, 1]) and an exact
# sum over the two values of X2 (binary).  The inner integrations over Z
# (Gauss-Hermite in true.int.lambda()) and over U (fine uniform grid in
# true.lambda()) are already deterministic and are reused unchanged.
#
# Motivation.  true.delta.late() draws N = 500,000 Monte Carlo samples of
# (X1, X2) and computes sample means of several integrals.  Residual MC
# error in the resulting true.params is of order 1/sqrt(N) and is the
# SAME across all simulation replications, so it acts as a fixed offset
# in the "observed bias" computed by the figure scripts.  Once that
# offset is scaled by sqrt(n) in the integrated-scaled-bias metric, it
# grows with simulation sample size n -- potentially masquerading as
# estimator bias growth.  Gauss-Legendre quadrature drops the
# X-integration error well below 1e-10 for the smooth integrands here,
# eliminating this confound entirely.
#
# Use this in place of true.delta.late() when computing true.params for
# the make_data() DGP; the two functions should agree to within the MC
# error of true.delta.late() (a few thousandths per delta component).
#
# @param delta  Sensitivity parameter (scalar).
# @param ATE    True average treatment effect (same role as in make_data).
# @param n_gl   Number of Gauss-Legendre nodes for X1 (default 80).
#               Smooth integrands here are typically converged to machine
#               precision at n_gl in [40, 80]; increase for stress tests.
# @return       Scalar, the true value of psi(delta) under make_data.
# =============================================================================
true.delta.late.det <- function(delta, ATE, n_gl = 80) {
  gl <- gauss.quad(n_gl, kind = "legendre")
  x1_nodes <- gl$nodes
  # Scale weights by 0.5 to incorporate the X1 ~ Uniform(-1, 1) density:
  # sum(x1_wts * f(x1_nodes)) then approximates E[f(X1)].
  x1_wts   <- gl$weights * 0.5

  # Expectation of f(X1, X2) under the joint marginal distribution of
  # (X1, X2): mix over X2 with Pr(X2 = 1) = 0.3.
  E_X <- function(f) {
    f_x2_0 <- vapply(x1_nodes, function(x1) f(x1, 0), numeric(1))
    f_x2_1 <- vapply(x1_nodes, function(x1) f(x1, 1), numeric(1))
    0.7 * sum(x1_wts * f_x2_0) + 0.3 * sum(x1_wts * f_x2_1)
  }

  # Numerator: E[gamma^Y_delta(X)] - E[Y]
  #          = E[r(X) * gamma^A_delta(X)] - E[r(X) * gamma^A_0(X)]
  # The outcome intercept gamma(X) = 40 - 7*X1 - 8*X2 cancels because it
  # does not depend on delta, as does the 1.5*U term (E[U | X] = 0).
  num <- E_X(function(x1, x2) {
    (ATE - 4 * x1 + 6 * (x2 - 0.3)) * true.int.lambda(x1, x2, delta)
  }) - E_X(function(x1, x2) {
    (ATE - 4 * x1 + 6 * (x2 - 0.3)) * true.int.lambda(x1, x2, 0)
  })

  # Denominator: E[gamma^A_delta(X)] - E[A]
  #            = E[gamma^A_delta(X)] - E[gamma^A_0(X)]
  den <- E_X(function(x1, x2) true.int.lambda(x1, x2, delta)) -
         E_X(function(x1, x2) true.int.lambda(x1, x2, 0))

  num / den
}


# =============================================================================
# make_data_nonlinear
#
# Paper 1 Option B: current 2-covariate DGP plus nonlinearity in the outcome
# regressions r(X) and gamma(X).  Designed so that plug-in estimators using
# SuperLearner libraries without sufficient flexibility (or parametric-only
# libraries) will carry persistent misspecification bias, while the DRML
# influence-function correction should largely eliminate it.
#
# Changes from make_data():
#   r.X      : LATE - 4*X1 + 6*(X2 - 0.3)      -->  LATE - 4*sin(pi*X1) + 6*(X2 - 0.3)
#   gamma.X  : 40 - 7*X1 - 8*X2                -->  40 - 7*X1^2 - 8*X2
#
# Unchanged:
#   Z | X  ~ N(0.4*X1 - 0.8*X2, 9)     (preserves closed-form alpha_delta)
#   A | X, Z, U  logistic-linear as before (preserves true.int.lambda)
#
# Because Z | X and A | X, Z, U are unchanged, true.int.lambda() from the
# original DGP is reused.  Only true.int.mu needs to be replaced by
# true.int.mu.nonlinear(), and true.delta.late by true.delta.late.nonlinear().
# =============================================================================
make_data_nonlinear <- function(n, LATE) {
  X1 <- runif(n, -1, 1)
  X2 <- rbinom(n, 1, 0.3)
  U  <- runif(n, -1.5, 1.5)
  X  <- cbind.data.frame(X1, X2)

  Z <- rnorm(n, 0.4 * X[, 1] - 0.8 * X[, 2], 3)
  A <- rbinom(n, 1,
              plogis(-0.3 - 0.4 * X[, 1] - 0.14 * X[, 2] + 1.1 * Z + 0.7 * U))

  # Nonlinear outcome components
  r.X     <- LATE - 4 * sin(pi * X[, 1]) + 6 * (X[, 2] - 0.3)
  gamma.X <- 40 - 7 * X[, 1]^2 - 8 * X[, 2]
  e.Y     <- rnorm(n, sd = 2)
  Y       <- r.X * A + gamma.X + 1.5 * U + e.Y

  simDat <- data.frame(cbind(Z, Y, A, X1, X2))
  return(simDat)
}

# Companion true-LATE computation for make_data_nonlinear.
# true.int.lambda() is unchanged (A model unchanged), so only r(X) is updated.
true.int.mu.nonlinear <- function(x1, x2, delta, ATE) {
  (ATE - 4 * sin(pi * x1) + 6 * (x2 - 0.3)) * true.int.lambda(x1, x2, delta)
}

true.delta.late.nonlinear <- function(delta, ATE) {
  N  <- 100000
  X1 <- runif(N, -1, 1)
  X2 <- rbinom(N, 1, 0.3)

  numerator <- mean(sapply(1:N, function(i) {
    true.int.mu.nonlinear(X1[i], X2[i], delta, ATE)
  }, simplify = 0)) -
    mean(sapply(1:N, function(i) {
      true.int.mu.nonlinear(X1[i], X2[i], 0, ATE)
    }, simplify = 0))
  denominator <- mean(sapply(1:N, function(i) {
    true.int.lambda(X1[i], X2[i], delta)
  }, simplify = 0)) -
    mean(sapply(1:N, function(i) {
      true.int.lambda(X1[i], X2[i], 0)
    }, simplify = 0))
  numerator / denominator
}


# =============================================================================
# Deterministic version of true.delta.late.nonlinear.
#
# Same structure as true.delta.late.det (Gauss-Legendre over X1, exact sum
# over X2), but using the nonlinear r(X) = ATE - 4*sin(pi*X1) + 6*(X2-0.3)
# from make_data_nonlinear.  The inner integrations (over Z and U) are
# identical to the linear DGP because make_data_nonlinear leaves the A model
# and Z|X distribution unchanged.
#
# @param delta  Sensitivity parameter.
# @param ATE    True average treatment effect.
# @param n_gl   Number of Gauss-Legendre nodes for X1 (default 80).
# @return       Scalar, true value of psi(delta) under make_data_nonlinear.
# =============================================================================
true.delta.late.nonlinear.det <- function(delta, ATE, n_gl = 80) {
  gl <- gauss.quad(n_gl, kind = "legendre")
  x1_nodes <- gl$nodes
  x1_wts   <- gl$weights * 0.5

  E_X <- function(f) {
    f_x2_0 <- vapply(x1_nodes, function(x1) f(x1, 0), numeric(1))
    f_x2_1 <- vapply(x1_nodes, function(x1) f(x1, 1), numeric(1))
    0.7 * sum(x1_wts * f_x2_0) + 0.3 * sum(x1_wts * f_x2_1)
  }

  # Nonlinear r(X) is the only difference from the linear-DGP version.
  r_X <- function(x1, x2) ATE - 4 * sin(pi * x1) + 6 * (x2 - 0.3)

  num <- E_X(function(x1, x2) r_X(x1, x2) * true.int.lambda(x1, x2, delta)) -
         E_X(function(x1, x2) r_X(x1, x2) * true.int.lambda(x1, x2, 0))

  den <- E_X(function(x1, x2) true.int.lambda(x1, x2, delta)) -
         E_X(function(x1, x2) true.int.lambda(x1, x2, 0))

  num / den
}


# =============================================================================
# make_data_complex
#
# Richer DGP for the follow-up paper.  Five covariates (mix of continuous
# and binary), nonlinear and interactive effects in both treatment and
# outcome models, but keeping Z | X linear-Gaussian so alpha_delta(X) retains
# a closed form and oracle nuisance checks remain tractable.
#
#   X1 ~ Uniform(-1, 1)    continuous
#   X2 ~ Bernoulli(0.3)    binary
#   X3 ~ N(0, 1)           continuous
#   X4 ~ Uniform(0, 1)     continuous
#   X5 ~ Bernoulli(0.5)    binary
#   U  ~ Uniform(-1.5, 1.5)  unmeasured confounder
#
# Z | X ~ N(0.4*X1 - 0.8*X2 + 0.3*X3 - 0.5*X4 + 0.6*X5, 9)
# A | X, Z, U ~ Bernoulli(plogis(eta_A)), eta_A nonlinear in X with interactions
# Y = r(X) * A + gamma(X) + 1.5*U + eps_Y    with nonlinear r(X), gamma(X)
#
# Note for Sim-Parallel.R: extract covariates as
#   x <- as.matrix(dat[, c("X1", "X2", "X3", "X4", "X5")])
# rather than just X1, X2.
# =============================================================================
make_data_complex <- function(n, LATE) {
  X1 <- runif(n, -1, 1)
  X2 <- rbinom(n, 1, 0.3)
  X3 <- rnorm(n, 0, 1)
  X4 <- runif(n, 0, 1)
  X5 <- rbinom(n, 1, 0.5)
  U  <- runif(n, -1.5, 1.5)

  # Z | X: linear-Gaussian (preserves closed-form alpha_delta)
  mu_Z <- 0.4 * X1 - 0.8 * X2 + 0.3 * X3 - 0.5 * X4 + 0.6 * X5
  Z    <- rnorm(n, mu_Z, 3)

  # Treatment: logistic with interactions, still linear in Z
  eta_A <- -0.3 - 0.4 * X1 - 0.14 * X2 + 0.5 * X3 - 0.3 * X4 + 0.2 * X5 +
           0.3 * X1 * X3 - 0.2 * X2 * X4 + 1.1 * Z + 0.7 * U
  A     <- rbinom(n, 1, plogis(eta_A))

  # Outcome: smooth nonlinearities in r(X) and gamma(X)
  r.X     <- LATE + 2 * sin(pi * X1) - 1.5 * X2 + X3 * X4 - 0.5 * X5
  gamma.X <- 40 - 5 * X1^2 + 3 * X2 * X3 - 2 * X4 + 4 * X5 * X1
  e.Y     <- rnorm(n, sd = 2)
  Y       <- r.X * A + gamma.X + 1.5 * U + e.Y

  simDat <- data.frame(cbind(Z, Y, A, X1, X2, X3, X4, X5))
  return(simDat)
}

# -----------------------------------------------------------------------------
# Companion true-LATE computation for make_data_complex.
#
# Because the A-model coefficients and covariate set both change, both
# true.lambda and true.int.lambda must be rewritten.  Z | X is still
# N(mu_Z, 9) with sd = 3, so Gauss-Hermite quadrature over Z applies.
# -----------------------------------------------------------------------------
true.lambda.complex <- function(x1, x2, x3, x4, x5, z) {
  grid.width <- 0.005
  us <- seq(-1.5, 1.5, by = grid.width)
  eta <- -0.3 - 0.4 * x1 - 0.14 * x2 + 0.5 * x3 - 0.3 * x4 + 0.2 * x5 +
         0.3 * x1 * x3 - 0.2 * x2 * x4 + 1.1 * z + 0.7 * us
  grid.width * sum(plogis(eta) / 3)
}

true.int.lambda.complex <- function(x1, x2, x3, x4, x5, delta) {
  mu_Z <- 0.4 * x1 - 0.8 * x2 + 0.3 * x3 - 0.5 * x4 + 0.6 * x5
  herm.input <- sqrt(2) * 3 * gh.nodes + mu_Z
  h.for.quad <- sapply(1:N.nodes, function(j) {
    exp(delta * herm.input[j]) *
      true.lambda.complex(x1, x2, x3, x4, x5, herm.input[j])
  }, simplify = 0) / exp(delta * mu_Z + 9 * delta^2 / 2)
  sum(h.for.quad * gh.weights) / sqrt(pi)
}

true.int.mu.complex <- function(x1, x2, x3, x4, x5, delta, ATE) {
  r.X <- ATE + 2 * sin(pi * x1) - 1.5 * x2 + x3 * x4 - 0.5 * x5
  r.X * true.int.lambda.complex(x1, x2, x3, x4, x5, delta)
}

true.delta.late.complex <- function(delta, ATE) {
  N  <- 100000
  X1 <- runif(N, -1, 1)
  X2 <- rbinom(N, 1, 0.3)
  X3 <- rnorm(N, 0, 1)
  X4 <- runif(N, 0, 1)
  X5 <- rbinom(N, 1, 0.5)

  numerator <- mean(sapply(1:N, function(i) {
    true.int.mu.complex(X1[i], X2[i], X3[i], X4[i], X5[i], delta, ATE)
  }, simplify = 0)) -
    mean(sapply(1:N, function(i) {
      true.int.mu.complex(X1[i], X2[i], X3[i], X4[i], X5[i], 0, ATE)
    }, simplify = 0))
  denominator <- mean(sapply(1:N, function(i) {
    true.int.lambda.complex(X1[i], X2[i], X3[i], X4[i], X5[i], delta)
  }, simplify = 0)) -
    mean(sapply(1:N, function(i) {
      true.int.lambda.complex(X1[i], X2[i], X3[i], X4[i], X5[i], 0)
    }, simplify = 0))
  numerator / denominator
}


# =============================================================================
# Deterministic version of true.delta.late.complex.
#
# Five-dimensional deterministic quadrature over the covariate distribution:
#   X1 ~ Uniform(-1, 1)   : Gauss-Legendre on [-1, 1], weights * 0.5
#   X2 ~ Bernoulli(0.3)   : exact sum, probabilities (0.7, 0.3)
#   X3 ~ N(0, 1)          : Gauss-Hermite, nodes sqrt(2) * gh.nodes,
#                                          weights gh.weights / sqrt(pi)
#   X4 ~ Uniform(0, 1)    : Gauss-Legendre mapped from [-1, 1],
#                           nodes (t + 1)/2, weights * 0.5 (Jacobian)
#   X5 ~ Bernoulli(0.5)   : exact sum, probabilities (0.5, 0.5)
#
# The 5D grid is flattened into a single table of nodes and weights so the
# integrand can be evaluated in a single mapply rather than a 5-deep nested
# loop; mapply still has per-call R overhead but avoids R-level loop control.
#
# Runtime.  Dominated by calls to true.int.lambda.complex, which itself
# loops over the Gauss-Hermite Z grid and the U grid.  For n_gl = 20 the
# flattened grid has 20 * 2 * 10 * 20 * 2 = 16,000 rows per expectation,
# and four expectations per delta value (numerator/denom at delta and 0).
# Expect roughly 2--4 minutes per delta on a single core; the default
# 6-point delta grid runs in 15--30 minutes total.  This is still much
# faster (and much more accurate) than the N = 100,000 MC version.
#
# @param delta  Sensitivity parameter.
# @param ATE    True average treatment effect.
# @param n_gl   Number of Gauss-Legendre nodes for each of X1 and X4
#               (default 20).  Smooth integrands here converge to machine
#               precision well before n_gl = 20; increase only for stress
#               testing.
# @return       Scalar, true value of psi(delta) under make_data_complex.
# =============================================================================
true.delta.late.complex.det <- function(delta, ATE, n_gl = 20) {
  # Continuous X1 on [-1, 1]: Gauss-Legendre, weight incorporates density 0.5
  gl        <- gauss.quad(n_gl, kind = "legendre")
  x1_nodes  <- gl$nodes
  x1_wts    <- gl$weights * 0.5

  # Continuous X4 on [0, 1]: rescale GL from [-1, 1] with Jacobian 1/2;
  # uniform density is 1 so no further adjustment.
  x4_nodes  <- (gl$nodes + 1) / 2
  x4_wts    <- gl$weights * 0.5

  # Continuous X3 ~ N(0, 1): Gauss-Hermite substitution X3 = sqrt(2) * t
  # gives E[g(X3)] = (1 / sqrt(pi)) * sum(gh.weights * g(sqrt(2) * gh.nodes)).
  # gh.nodes and gh.weights are the 10-node tables defined at the top of
  # this file.
  x3_nodes  <- sqrt(2) * gh.nodes
  x3_wts    <- gh.weights / sqrt(pi)

  # Binary covariates: exact two-point sums.
  x2_vals   <- c(0, 1);   x2_probs <- c(0.7, 0.3)
  x5_vals   <- c(0, 1);   x5_probs <- c(0.5, 0.5)

  # Flatten the 5D tensor grid.  expand.grid iterates the first argument
  # fastest, so the resulting columns can be indexed directly.
  grid <- expand.grid(
    i1 = seq_along(x1_nodes),
    i2 = seq_along(x2_vals),
    i3 = seq_along(x3_nodes),
    i4 = seq_along(x4_nodes),
    i5 = seq_along(x5_vals),
    KEEP.OUT.ATTRS = FALSE
  )
  w_flat  <- x1_wts[grid$i1] * x2_probs[grid$i2] *
             x3_wts[grid$i3] * x4_wts[grid$i4] *
             x5_probs[grid$i5]
  x1_flat <- x1_nodes[grid$i1]
  x2_flat <- x2_vals[grid$i2]
  x3_flat <- x3_nodes[grid$i3]
  x4_flat <- x4_nodes[grid$i4]
  x5_flat <- x5_vals[grid$i5]

  # Expectation of f(X1, ..., X5) under the full joint marginal.
  E_X <- function(f) {
    vals <- mapply(f, x1_flat, x2_flat, x3_flat, x4_flat, x5_flat)
    sum(w_flat * vals)
  }

  # r(X) matches make_data_complex: LATE + 2*sin(pi*X1) - 1.5*X2 + X3*X4 - 0.5*X5
  r_X <- function(x1, x2, x3, x4, x5) {
    ATE + 2 * sin(pi * x1) - 1.5 * x2 + x3 * x4 - 0.5 * x5
  }

  num <- E_X(function(x1, x2, x3, x4, x5) {
           r_X(x1, x2, x3, x4, x5) *
             true.int.lambda.complex(x1, x2, x3, x4, x5, delta)
         }) -
         E_X(function(x1, x2, x3, x4, x5) {
           r_X(x1, x2, x3, x4, x5) *
             true.int.lambda.complex(x1, x2, x3, x4, x5, 0)
         })

  den <- E_X(function(x1, x2, x3, x4, x5) {
           true.int.lambda.complex(x1, x2, x3, x4, x5, delta)
         }) -
         E_X(function(x1, x2, x3, x4, x5) {
           true.int.lambda.complex(x1, x2, x3, x4, x5, 0)
         })

  num / den
}


       