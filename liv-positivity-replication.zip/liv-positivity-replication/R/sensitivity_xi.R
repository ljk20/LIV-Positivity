# =============================================================================
# sensitivity_xi.R
#
# Sensitivity analysis for the monotonicity assumption (Section 5.2).
# Implements equation (16):
#
#   xi_delta(g1, g2) = psi_IF(delta) + g1*g2 / Pn[(1 - exp(delta*Z)/alpha)
#                                                * (gamma^A_delta(X) - A)]
#
# where (gamma_1(delta), gamma_2(delta)) are the (defier proportion, defier-vs-
# complier effect contrast) pair.  sen() takes their product as g1.g2 and
# returns xi together with the IF estimate of psi(delta) and the denominator
# of the bias correction (sign of which indicates whether xi is upper- or
# lower-bounding psi).
#
# Mirrors late-funcs-fast.R conventions: SuperLearner ensemble nuisance
# estimation, ratio-form gamma_Y / gamma_A, lower-cased y/a/z column lookup,
# mclapply over the delta grid.
# =============================================================================

library(SuperLearner)
library(ranger)

# =============================================================================
# Custom SuperLearner wrappers (mirrors late-funcs-fast.R)
# =============================================================================

SL.ranger.st <- function(Y, X, newX, family, obsWeights, ...) {
  num.trees <- max(500L, ceiling(10L * sqrt(length(Y))))
  SL.ranger(Y = Y, X = X, newX = newX, family = family,
            obsWeights = obsWeights, num.trees = num.trees,
            num.threads = 1L, ...)
}

SL.glm.loglink <- function(Y, X, newX, family, obsWeights, ...) {
  df <- cbind(Y = Y, as.data.frame(X))
  fit <- tryCatch(
    glm(Y ~ ., data = df, family = gaussian(link = "log"),
        weights = obsWeights,
        start   = c(log(max(mean(Y), 1e-8)), rep(0, ncol(X)))),
    error = function(e) {
      warning("SL.glm.loglink: log-link GLM failed (", conditionMessage(e),
              "); falling back to identity link.")
      glm(Y ~ ., data = df, weights = obsWeights)
    }
  )
  pred    <- pmax(predict(fit, newdata = as.data.frame(newX), type = "response"),
                 .Machine$double.eps)
  fit_obj <- list(object = fit)
  class(fit_obj) <- "SL.glm.loglink"
  list(pred = pred, fit = fit_obj)
}

predict.SL.glm.loglink <- function(object, newdata, ...) {
  pmax(predict(object$object, newdata = as.data.frame(newdata),
               type = "response"),
       .Machine$double.eps)
}

.register_sl_wrappers <- function() {
  wrappers <- list(SL.ranger.st           = SL.ranger.st,
                   SL.glm.loglink         = SL.glm.loglink,
                   predict.SL.glm.loglink = predict.SL.glm.loglink)
  for (nm in names(wrappers)) {
    if (!exists(nm, envir = .GlobalEnv, inherits = FALSE)) {
      assign(nm, wrappers[[nm]], envir = .GlobalEnv)
    }
  }
}

# =============================================================================
# sen: sensitivity-corrected delta-tilted LATE.
# =============================================================================

#' @param dat       Data frame with columns y, a, z (case-insensitive).
#' @param x         Covariate matrix (n x p).
#' @param delta.seq Tilt parameter grid (scalar or vector).
#' @param g1.g2     Product gamma_1(delta) * gamma_2(delta).
#' @param nsplits   Cross-fitting folds (default 2).
#' @param sl.lib    SuperLearner library for gamma_Y, gamma_A.
#' @param ncores    Cores for parallel::mclapply over delta values.
#'
#' @return Named list: xi_hat, est.eff, deno_sen.
sen <- function(dat, x, delta.seq, g1.g2,
                nsplits = 2,
                sl.lib = c("SL.ranger", "SL.mean", "SL.glm"),
                ncores = 1L) {

  .register_sl_wrappers()
  colnames(dat) <- tolower(colnames(dat))
  n <- nrow(dat)
  k <- length(delta.seq)
  colnames(x) <- paste0("x", seq_len(ncol(x)))
  x_df <- as.data.frame(x)
  sl.lib.alpha <- unique(c(sl.lib, "SL.glm.loglink"))

  num <- matrix(NA_real_, nrow = n, ncol = k)
  den <- matrix(NA_real_, nrow = n, ncol = k)

  s <- sample(rep(seq_len(nsplits), ceiling(n / nsplits))[seq_len(n)])

  for (fold in seq_len(nsplits)) {

    train_idx <- which(s != fold)
    test_idx  <- which(s == fold)
    x_train   <- x_df[train_idx, , drop = FALSE]

    fold_fits <- parallel::mclapply(seq_len(k), function(j) {

      delta  <- delta.seq[j]
      exp_dz <- exp(delta * dat$z)

      alpha_fit <- SuperLearner(
        Y          = exp_dz[train_idx],
        X          = x_train,
        SL.library = sl.lib.alpha,
        cvControl  = list(V = 10L),
        verbose    = FALSE
      )
      alpha_hat <- predict(alpha_fit, newdata = x_df)$pred

      gammaY_fit <- SuperLearner(
        Y          = (dat$y * exp_dz)[train_idx],
        X          = x_train,
        SL.library = sl.lib,
        cvControl  = list(V = 10L),
        verbose    = FALSE
      )
      gamma_Y <- predict(gammaY_fit, newdata = x_df)$pred / alpha_hat

      gammaA_fit <- SuperLearner(
        Y          = (dat$a * exp_dz)[train_idx],
        X          = x_train,
        SL.library = sl.lib,
        cvControl  = list(V = 10L),
        verbose    = FALSE
      )
      gamma_A <- predict(gammaA_fit, newdata = x_df)$pred / alpha_hat

      wt <- 1 - exp_dz / alpha_hat
      list(
        num = (wt * (gamma_Y - dat$y))[test_idx],
        den = (wt * (gamma_A - dat$a))[test_idx]
      )

    }, mc.cores = ncores)

    for (j in seq_len(k)) {
      num[test_idx, j] <- fold_fits[[j]]$num
      den[test_idx, j] <- fold_fits[[j]]$den
    }
  }

  est.eff  <- numeric(k)
  deno_sen <- numeric(k)
  xi       <- numeric(k)

  for (j in seq_len(k)) {
    deno_sen[j] <- mean(den[, j])
    est.eff[j]  <- mean(num[, j]) / deno_sen[j]
    xi[j]       <- est.eff[j] + g1.g2 / deno_sen[j]
  }

  list(xi_hat = xi, est.eff = est.eff, deno_sen = deno_sen)
}
