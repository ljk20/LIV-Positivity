# Replication archive: *Local Effects of Continuous Instruments without Positivity*

Reproduces the empirical analyses and simulation study in:

> Rakshit, P., Levis, A. W., and Keele, L. (2026). Local Effects of Continuous
> Instruments without Positivity. *Journal of the Royal Statistical Society,
> Series B*.


## Quickstart

```bash
git clone https://github.com/<your-org>/liv-positivity-replication.git
cd liv-positivity-replication
R -e 'install.packages("renv"); renv::restore()'
Rscript run_all.R
```

## What gets reproduced

| Manuscript element | Script(s) | Output file(s) |
|---|---|---|
| Figure 4 (positivity-violation diagnostic) | `application/01_density-estimation.R`, `application/04_figure-4.R` | `figures/application/tto_positivity.pdf` |
| Figure 5 (δ-tilted LATE) | `application/02_estimation.R`, `application/05_figure-5.R` | `figures/application/tto-est-1.pdf`, `tto-est-2.pdf` |
| Figure S6 (principal-strata profiles) | `application/03_estimation-supp.R`, `application/06_figure-S6.R` | `sepsis-profile.pdf`, `age-profile-1.pdf`, `age-profile-2.pdf` |
| Figure S7 (monotonicity sensitivity) | `application/03_estimation-supp.R`, `application/07_figure-S7.R` | `mono-sens-low-delta.pdf`, `mono-sens-high-delta.pdf` |
| §6 simulation figures (4 panels) | `simulation/01_sim-parallel.R`, `simulation/02_sim-figures.R` | `figures/simulation/sim1-fig{1,2,3,4}*.pdf` |
| §7 numerical claims (complier share, ψ̂(0+), homogeneous-effect test) | `application/02_estimation.R`, `application/05_figure-5.R` | printed to stdout when `05_figure-5.R` runs |

## Repository layout

```
liv-positivity-replication/
├── R/                          shared estimator code
├── application/                cholecystitis / TTO scripts (numbered)
├── simulation/                 Monte Carlo scripts (numbered)
├── output/                     intermediate .RData (created at runtime)
├── figures/                    final PDFs (created at runtime)
├── run_all.R                   master driver
├── README.md                   this file
├── .Rprofile                   activates renv on startup
└── renv.lock                   pinned R package versions (after `renv::init()`)
```

## Dependencies

R ≥ 4.3.0 with the following CRAN packages (managed via `renv`):

| Package | Used in |
|---|---|
| `tidyverse` | application, simulation |
| `here` | application, simulation |
| `foreign` | application (Stata file I/O) |
| `fixest` | application (hospital FE residualization) |
| `np` | application (conditional density estimation) |
| `ranger` | both (random forests via SuperLearner) |
| `SuperLearner` | simulation; loaded transitively by application |
| `mvtnorm` | application, simulation |
| `parallel` | application, simulation |
| `furrr`, `future` | simulation (parallel replications) |
| `ggplot2`, `gridExtra`, `patchwork`, `scales` | figure scripts |

`renv::init()` followed by `renv::snapshot()` will write the exact pinned
versions to `renv.lock`. After cloning, `renv::restore()` will install those
versions into a project-local library.

## Data

The application data are restricted and cannot be redistributed; obtain a
copy from the original providers.

## Re-running individual pieces

```bash
# Just the simulation, figures included
Rscript simulation/01_sim-parallel.R
Rscript simulation/02_sim-figures.R

# Just the application, no positivity figure
Rscript application/02_estimation.R
Rscript application/03_estimation-supp.R
Rscript application/05_figure-5.R
Rscript application/06_figure-S6.R
Rscript application/07_figure-S7.R
```




